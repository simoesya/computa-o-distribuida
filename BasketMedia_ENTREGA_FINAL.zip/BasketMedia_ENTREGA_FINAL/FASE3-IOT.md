# Fase 3 — Dashboard de sensores IoT

## Correspondência com o enunciado

| Requisito | Implementação |
|---|---|
| Interface de front end com dashboard IoT | Página `/dashboard`, template `web/templates/dashboard.html` |
| Acesso por JavaScript/API REST | `web/static/js/dashboard.js` chama `GET /api/iot/weather/rest`; o Flask consome `/weather/values` e `/weather/position` |
| Acesso por MQTT | `web/iot_weather.py` autentica-se com as credenciais do professor e subscreve o tópico `/weather` com Paho MQTT |
| Sensor escolhido | Sensor Weather: temperatura e humidade |
| Considerar CORS | O browser usa um proxy local Flask, evitando pedidos cross-origin diretos |
| Atualização periódica | `dashboard.js` atualiza automaticamente a cada 10 segundos |
| Mapa opcional | Mapa Leaflet com pin e popup do sensor |
| Contentores | `web`, `data-api` e `db` definidos no Docker Compose |
| Cliente/servidor | Browser → web; web → data-api; web → API Weather/Broker; data-api → MariaDB |
| JSON | API REST e mensagens MQTT são interpretadas como JSON |

## Fluxo REST

```text
Browser
  -> GET /api/iot/weather/rest
  -> Flask web
  -> GET https://cjsg.ddns.net:8443/weather/values
  -> GET https://cjsg.ddns.net:8443/weather/position
  -> JSON normalizado
  -> Browser
```

A rota principal do sensor fornece temperatura, humidade e hora. A rota de posição é consultada para obter latitude e longitude. Se a posição falhar, a leitura principal continua a ser apresentada.

## Fluxo MQTT

```text
Sensor Weather (publisher)
  -> tópico /weather
  -> broker MQTT
  -> subscriber Paho no contentor web
  -> cache da última mensagem
  -> GET /api/iot/weather/mqtt
  -> Browser
```

O subscriber inicia com o contentor `web`, lê as credenciais de `config/mqtt.env`, autentica-se no broker, mantém a última mensagem recebida em memória e volta a subscrever o tópico quando a ligação é restabelecida. Enquanto está ligado mas ainda não existe publicação, a rota devolve o estado `waiting` com HTTP 200 e o dashboard apresenta **A aguardar dados**.

## CORS

Um pedido JavaScript diretamente de `http://localhost:5000` para `https://cjsg.ddns.net:8443` é um pedido entre origens diferentes. O resultado dependeria dos cabeçalhos CORS enviados pelo servidor do professor.

A solução implementada é um **proxy do lado do servidor**:

1. o JavaScript chama apenas uma rota local;
2. o Flask faz o pedido ao serviço externo;
3. o Flask devolve JSON ao JavaScript.

Desta forma, o front end não precisa de contornar nem desativar a segurança CORS do browser.

## Ficheiros principais

```text
web/iot_weather.py                 cliente REST + subscriber MQTT
web/templates/dashboard.html      estrutura visual
web/static/js/dashboard.js        atualização e mapa
web/static/css/style.css           estilos do dashboard
web/server.py                      rotas locais do dashboard
```

## Teste rápido

1. Executar `docker compose up --build`.
2. Registar ou entrar numa conta.
3. Abrir `http://localhost:5000/dashboard`.
4. Confirmar que o painel REST apresenta temperatura e humidade.
5. Confirmar que o painel MQTT muda de “A aguardar” para “Ligado” quando chega uma mensagem.
6. Confirmar atualização automática após 10 segundos.
7. Abrir “Ver resposta JSON” e “Ver mensagem JSON”.
8. Confirmar o pin no mapa quando existem coordenadas.

Se o REST funcionar e o MQTT não receber mensagens, verificar `docker compose logs -f web`. As credenciais do professor já estão em `config/mqtt.env`; o estado **A aguardar dados** significa que a ligação está preparada, mas ainda não chegou uma publicação no tópico.
