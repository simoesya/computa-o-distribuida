# API REST do projeto

## Autenticação interna

As rotas da `data-api` associadas a conteúdos e pavilhões recebem o identificador do utilizador no header interno:

```http
X-User-Id: 1
```

Este header é colocado pelo contentor `web` e a `data-api` não está publicada para o exterior.

## Autenticação

### `POST /auth/register`

Pedido:

```json
{
  "username": "aluno",
  "password": "password123"
}
```

Respostas principais: `201`, `400`, `409`.

### `POST /auth/login`

Pedido:

```json
{
  "username": "aluno",
  "password": "password123"
}
```

Respostas principais: `200`, `401`.

## Conteúdos

- `GET /contents?q=texto` — lista ou pesquisa conteúdos.
- `GET /contents?ids=1,2,3` — lista conteúdos pelos identificadores.
- `GET /contents/<id>` — obtém um conteúdo.
- `POST /contents` — cria um conteúdo.
- `PUT /contents/<id>` — altera os metadados.
- `DELETE /contents/<id>` — elimina o registo.

Exemplo de criação:

```json
{
  "media_type": "image",
  "category": "moment",
  "name": "Treino",
  "description": "Treino no pavilhão",
  "lat": 38.7223,
  "lon": -9.1393,
  "media_filename": "treino.jpg",
  "thumb_filename": null
}
```

## Pavilhões

- `GET /courts`
- `POST /courts`
- `DELETE /courts/<id>`

Exemplo de criação:

```json
{
  "name": "Pavilhão A",
  "info": "Campo principal",
  "lat": 38.7223,
  "lon": -9.1393
}
```

## Gateway IoT exposto pelo `web`

Estas rotas são consumidas pelo JavaScript da página e exigem uma sessão iniciada.

### `GET /api/iot/weather/rest`

Consome a API REST externa e devolve:

```json
{
  "ok": true,
  "source": "REST",
  "received_at": "2026-06-14T12:00:00+00:00",
  "weather": {
    "name": "Weather",
    "temperature": 23.4,
    "humidity": 51.2,
    "time": "2026-06-14T12:00:00",
    "latitude": 38.0,
    "longitude": -9.0
  }
}
```

### `GET /api/iot/weather/mqtt`

Devolve o estado do subscriber autenticado e, quando disponível, a última mensagem recebida no tópico MQTT:

```json
{
  "ok": true,
  "available": true,
  "state": "received",
  "authentication": "configured",
  "source": "MQTT",
  "connected": true,
  "broker": "cjsg.ddns.net:1883",
  "topic": "/weather",
  "message": {
    "received_at": "2026-06-14T12:00:00+00:00",
    "weather": {
      "temperature": 23.4,
      "humidity": 51.2
    }
  }
}
```

Enquanto a ligação estiver ativa mas ainda não existir uma mensagem, a rota devolve `200`, `state: "waiting"`, `available: false` e `message: null`. O código `503` fica reservado para um erro real de ligação/autenticação.

### `GET /api/iot/health`

Apresenta o estado resumido da integração REST/MQTT.


## Definição formal e ferramentas de teste

A interface REST pública está definida em OpenAPI 3 no ficheiro:

```text
web/docs/openapi.yaml
```

Durante a execução pode ser consultada em:

```text
http://localhost:5000/docs
http://localhost:5000/openapi.yaml
```

A coleção Postman encontra-se em:

```text
postman/BasketMedia.postman_collection.json
```

As rotas protegidas exigem uma sessão Flask. No Swagger, iniciar sessão primeiro no browser. No Postman, executar o pedido `Login`, que guarda o cookie automaticamente.
