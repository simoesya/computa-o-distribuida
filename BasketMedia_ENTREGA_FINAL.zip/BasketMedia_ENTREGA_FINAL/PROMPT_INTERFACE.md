# Prompt utilizado para definir a interface do BasketMedia

## Finalidade

Este ficheiro guarda o **prompt autónomo e reproduzível** utilizado para definir a interface do projeto. Pode ser copiado integralmente para uma ferramenta de IA sem depender do histórico de uma conversa.

## Prompt

```text
Desenvolve uma interface web completa, responsiva e funcional para uma aplicação chamada BasketMedia, destinada à gestão e visualização de conteúdos multimédia relacionados com basquetebol.

Tecnologias obrigatórias:
- Python com Flask no backend;
- templates Jinja2 e HTML sem frameworks frontend obrigatórios;
- CSS responsivo;
- JavaScript para interações e atualização de dados;
- Docker e Docker Compose;
- uma API REST interna para os dados da aplicação;
- MariaDB para persistência.

Arquitetura:
- separar a apresentação, a lógica da aplicação e os dados;
- disponibilizar externamente apenas o serviço web na porta 5000;
- o serviço web comunica com a data-api por HTTP/JSON;
- a data-api comunica com a MariaDB;
- a base de dados deve ficar numa rede Docker interna e não deve ser diretamente acessível pelo browser nem pelo contentor web.

A interface deve incluir:
1. Página de registo com username e password.
2. Página de login.
3. Página principal com listagem, pesquisa e filtragem de conteúdos.
4. Formulário para adicionar imagem, vídeo ou áudio por ficheiro ou URL.
5. Página de detalhe do conteúdo.
6. Edição e eliminação de conteúdos.
7. Mapa com conteúdos e pavilhões georreferenciados.
8. Dashboard IoT para o sensor Weather.
9. Página de documentação Swagger/OpenAPI acessível através de /docs.

Requisitos do dashboard IoT:
- apresentar temperatura e humidade;
- realizar obrigatoriamente um acesso por API REST;
- realizar obrigatoriamente um acesso por MQTT;
- usar a API REST base https://cjsg.ddns.net:8443/weather/;
- obter valores em /weather/values;
- obter a posição em /weather/position;
- usar o broker MQTT cjsg.ddns.net no porto 1883;
- subscrever o tópico /weather com autenticação por username/password lidos de variáveis de ambiente;
- atualizar o dashboard automaticamente a cada 10 segundos;
- apresentar a última leitura, hora, origem dos dados e estado do serviço;
- apresentar um mapa com a posição do sensor quando existirem coordenadas;
- não inventar valores MQTT: quando a ligação estiver ativa mas não forem recebidas mensagens, mostrar claramente “A aguardar dados”;
- nunca enviar ou mostrar a password MQTT no browser;
- permitir consultar o JSON recebido.

Tratamento de CORS:
- o JavaScript do browser não deve contactar diretamente a API REST externa;
- deve chamar uma rota local do Flask;
- o backend Flask funciona como proxy/gateway, contacta o sensor e devolve JSON ao browser;
- desta forma o browser comunica sempre com a mesma origem.

Requisitos visuais e de usabilidade:
- cabeçalho e navegação consistentes em todas as páginas;
- estado do utilizador visível;
- interface escura, legível e coerente;
- formulários com labels claros e mensagens de validação;
- estados “Online”, “Indisponível” e “A aguardar dados” claramente diferenciados;
- funcionamento em computador, tablet e telemóvel;
- não esconder erros: apresentar uma mensagem compreensível sem expor dados sensíveis.

Documentação e testes:
- criar um README.md com instruções completas de execução;
- criar documentação da arquitetura e da Fase 3;
- criar um ficheiro OpenAPI 3 para a interface REST pública;
- disponibilizar Swagger UI em /docs;
- criar uma coleção Postman importável;
- guardar este prompt num ficheiro Markdown do repositório;
- indicar os ficheiros onde cada parte da interface foi implementada.

Critérios de aceitação:
- docker compose up --build inicia web, data-api e db;
- o utilizador consegue registar-se e iniciar sessão;
- o dashboard abre depois do login;
- o painel REST apresenta os valores reais quando o serviço externo está disponível;
- o painel MQTT subscreve /weather e fica em “A aguardar dados” quando não existem mensagens;
- /docs abre a documentação Swagger;
- /openapi.yaml devolve uma especificação válida;
- a coleção Postman pode ser importada e usada para testar as rotas públicas.
```

## Correspondência com a implementação

| Requisito do prompt | Ficheiros principais |
|---|---|
| Navegação e estrutura comum | `web/templates/base.html` |
| Login e registo | `web/templates/login.html`, `web/templates/register.html`, `web/server.py` |
| Conteúdos multimédia | `web/templates/contents.html`, `web/templates/content_form.html`, `web/server.py` |
| Mapa | `web/templates/map.html`, `web/static/js/map.js` |
| Dashboard IoT | `web/templates/dashboard.html`, `web/static/js/dashboard.js` |
| REST, MQTT e CORS | `web/iot_weather.py`, `web/server.py` |
| Swagger/OpenAPI | `web/docs/openapi.yaml`, `web/templates/swagger.html` |
| Contentores | `docker-compose.yml`, `web/Dockerfile`, `data_service/Dockerfile` |

## Como comprovar que o resultado funciona

1. Executar `docker compose up --build`.
2. Abrir `http://localhost:5000`.
3. Criar uma conta e iniciar sessão.
4. Abrir `Dashboard IoT`.
5. Abrir `API / Swagger` ou `http://localhost:5000/docs`.
6. Confirmar que `http://localhost:5000/openapi.yaml` devolve a definição OpenAPI.
