# Definição da interface do BasketMedia

## 1. Interfaces existentes

O projeto possui duas interfaces complementares:

1. **Interface gráfica Web**, utilizada por uma pessoa através do browser.
2. **Interface REST**, utilizada pelo JavaScript do dashboard, Postman, Swagger e por outros componentes através de HTTP/JSON.

## 2. Interface gráfica

| Página | Endereço | Função |
|---|---|---|
| Registo | `/register` | Criar uma conta local. |
| Login | `/login` | Iniciar sessão. |
| Conteúdos | `/contents` | Listar e pesquisar conteúdos. |
| Adicionar | `/contents/new` | Criar um conteúdo por ficheiro ou URL. |
| Detalhe | `/contents/{id}` | Consultar um conteúdo. |
| Editar | `/contents/{id}/edit` | Alterar metadados. |
| Mapa | `/map` | Visualizar conteúdos e pavilhões georreferenciados. |
| Dashboard IoT | `/dashboard` | Consultar o sensor Weather por REST e MQTT. |
| Swagger | `/docs` | Consultar e testar a interface REST pública. |

### Estados principais

- **Online**: foi recebida uma resposta válida.
- **Indisponível**: ocorreu erro ao contactar o serviço REST.
- **A aguardar dados**: o subscriber MQTT está configurado, mas ainda não recebeu uma publicação.
- **Não autenticado**: o utilizador é redirecionado para o login ou recebe HTTP 401 nas rotas JSON.

## 3. Interface REST pública

A interface pública está definida formalmente em `openapi.yaml` e disponível durante a execução em:

```text
http://localhost:5000/openapi.yaml
```

A documentação interativa está em:

```text
http://localhost:5000/docs
```

Rotas principais:

| Método | Rota | Descrição |
|---|---|---|
| `GET` | `/api/contents` | Conteúdos preparados para a interface e para o mapa. |
| `GET` | `/api/search?q=...` | Pesquisa de conteúdos. |
| `GET` | `/api/courts` | Lista de pavilhões. |
| `POST` | `/api/courts` | Criação de pavilhão. |
| `DELETE` | `/api/courts/{id}` | Eliminação de pavilhão. |
| `GET` | `/api/iot/weather/rest` | Leitura do Weather por API REST através do proxy Flask. |
| `GET` | `/api/iot/weather/mqtt` | Última publicação MQTT recebida. |
| `GET` | `/api/iot/health` | Estado resumido da integração IoT. |

## 4. Sessão e autenticação

As rotas da interface pública utilizam a sessão Flask guardada num cookie. Para testar no browser:

1. Criar conta em `/register`.
2. Iniciar sessão em `/login`.
3. Abrir `/docs` na mesma sessão.

No Postman, executar primeiro o pedido **Login**. O Postman conserva automaticamente o cookie da sessão para os pedidos seguintes.

## 5. CORS

O dashboard não executa pedidos JavaScript diretamente para `cjsg.ddns.net`. O fluxo é:

```text
Browser -> /api/iot/weather/rest -> Flask -> API Weather externa
```

Como o browser comunica apenas com `localhost:5000`, o acesso não depende dos cabeçalhos CORS do servidor do professor.

## 6. MQTT

Configuração por omissão:

```text
Broker: cjsg.ddns.net
Porto: 1883
Tópico: /weather
```

O servidor Flask mantém um subscriber autenticado com as credenciais fornecidas pelo professor. A ausência de mensagens não gera dados simulados; se a ligação ao broker estiver ativa, a interface apresenta **A aguardar dados**. A password não é exposta nas respostas JSON.

## 7. Testes rápidos

```bash
docker compose up --build
```

Depois de iniciar sessão:

```text
http://localhost:5000/docs
http://localhost:5000/api/iot/health
http://localhost:5000/api/iot/weather/rest
http://localhost:5000/api/iot/weather/mqtt
```

Também é possível importar `postman/BasketMedia.postman_collection.json` no Postman.
