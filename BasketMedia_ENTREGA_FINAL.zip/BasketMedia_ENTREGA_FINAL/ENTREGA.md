# Checklist de entrega

## Antes de colocar no Git

- [ ] Preencher os nomes e números dos elementos do grupo em `RELATORIO.md`.
- [ ] Confirmar que o relatório descreve as Fases 1, 2 e 3.
- [ ] Confirmar que `config/mqtt.env` contém apenas as credenciais académicas partilhadas pelo professor e não credenciais pessoais.
- [ ] Confirmar que o projeto arranca com `docker compose up --build`.
- [ ] Criar uma conta e testar login.
- [ ] Abrir o dashboard IoT.
- [ ] Confirmar o estado REST ou a mensagem de indisponibilidade.
- [ ] Confirmar no dashboard que a autenticação MQTT aparece como configurada e que o estado é “Ligado” ou “A aguardar dados”.
- [ ] Abrir `http://localhost:5000/docs`.
- [ ] Confirmar que `http://localhost:5000/openapi.yaml` abre.
- [ ] Importar a coleção da pasta `postman`.

## Ficheiros pedidos/documentação

- [x] Prompt da interface: `PROMPT_INTERFACE.md`.
- [x] Definição da interface: `INTERFACE.md`.
- [x] Relatório Markdown das três fases: `RELATORIO.md`.
- [x] Swagger/OpenAPI: `openapi.yaml` e rota `/docs`.
- [x] Postman: `postman/BasketMedia.postman_collection.json`.
- [x] README com instruções de execução.

- [ ] Preencher os nomes e números na capa de `RELATORIO_BasketMedia_3_Fases.docx`.
- [ ] Confirmar a paginação e exportar para PDF apenas se o professor o pedir.
