import json
import os
import time
import traceback

import pymysql
from flask import Flask, jsonify, request
from werkzeug.security import generate_password_hash, check_password_hash

DB_HOST = os.getenv("DB_HOST", "db")
DB_PORT = int(os.getenv("DB_PORT", "3306"))
DB_NAME = os.getenv("DB_NAME", "basketmedia")
DB_USER = os.getenv("DB_USER", "basketmedia")
DB_PASSWORD = os.getenv("DB_PASSWORD", "basketmedia123")

BASE = os.path.dirname(os.path.abspath(__file__))
COURTS_FILE = os.path.join(BASE, "courts.json")

app = Flask(__name__)


def get_db():
    return pymysql.connect(
        host=DB_HOST,
        port=DB_PORT,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME,
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=True,
    )


COURTS_TABLE = "basket_courts"

COURTS_TABLE_SQL = f"""
CREATE TABLE IF NOT EXISTS {COURTS_TABLE}(
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    info TEXT NULL,
    lat DOUBLE NOT NULL,
    lon DOUBLE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_basket_courts_user (user_id)
) ENGINE=InnoDB
"""


def _table_exists(connection, table_name):
    with connection.cursor() as cur:
        cur.execute("SHOW TABLES LIKE %s", (table_name,))
        return cur.fetchone() is not None


def _table_columns(connection, table_name):
    with connection.cursor() as cur:
        cur.execute(f"SHOW COLUMNS FROM `{table_name}`")
        rows = cur.fetchall()
    return {row["Field"]: row for row in rows}


def _create_courts_table(connection):
    with connection.cursor() as cur:
        cur.execute(COURTS_TABLE_SQL)


def _court_table_is_compatible(connection):
    if not _table_exists(connection, COURTS_TABLE):
        return False

    columns = _table_columns(connection, COURTS_TABLE)
    required = {"id", "user_id", "name", "info", "lat", "lon", "created_at"}
    if not required.issubset(columns):
        return False

    if "auto_increment" not in str(columns["id"].get("Extra", "")).lower():
        return False

    # Uma coluna extra NOT NULL sem valor por omissão impediria os INSERTs.
    for field, definition in columns.items():
        if field in required:
            continue
        nullable = str(definition.get("Null", "YES")).upper() == "YES"
        default = definition.get("Default")
        extra = str(definition.get("Extra", "")).lower()
        if not nullable and default is None and "auto_increment" not in extra:
            return False

    return True


def _unique_backup_table_name(connection):
    base_name = f"{COURTS_TABLE}_backup"
    name = base_name
    number = 1
    while _table_exists(connection, name):
        number += 1
        name = f"{base_name}_{number}"
    return name


def _copy_rows_from_table(connection, source_table):
    """Copia os registos compatíveis de uma tabela antiga de pavilhões."""
    if not _table_exists(connection, source_table):
        return 0

    columns = _table_columns(connection, source_table)
    available = set(columns)
    name_col = next((x for x in ("name", "title", "nome") if x in available), None)
    info_col = next((x for x in ("info", "description", "descricao") if x in available), None)
    lat_col = next((x for x in ("lat", "latitude") if x in available), None)
    lon_col = next((x for x in ("lon", "lng", "longitude") if x in available), None)
    user_col = next((x for x in ("user_id", "userid", "owner_id") if x in available), None)

    if not name_col or not lat_col or not lon_col:
        return 0

    with connection.cursor() as cur:
        cur.execute(f"SELECT * FROM `{source_table}`")
        rows = cur.fetchall()
        cur.execute("SELECT id FROM users")
        valid_users = {int(row["id"]) for row in cur.fetchall()}

    if not valid_users:
        return 0
    fallback_user = min(valid_users)
    inserted = 0

    with connection.cursor() as cur:
        for row in rows:
            try:
                name = str(row.get(name_col) or "").strip()
                info = str(row.get(info_col) or "").strip() if info_col else ""
                lat = float(row.get(lat_col))
                lon = float(row.get(lon_col))
                if len(name) < 2 or not (-90 <= lat <= 90) or not (-180 <= lon <= 180):
                    continue

                user_id = row.get(user_col) if user_col else fallback_user
                try:
                    user_id = int(user_id)
                except (TypeError, ValueError):
                    user_id = fallback_user
                if user_id not in valid_users:
                    user_id = fallback_user

                # Evita duplicados ao migrar mais do que uma vez.
                cur.execute(
                    f"""
                    SELECT id FROM {COURTS_TABLE}
                    WHERE user_id = %s AND name = %s
                      AND ABS(lat - %s) < 0.000001
                      AND ABS(lon - %s) < 0.000001
                    LIMIT 1
                    """,
                    (user_id, name, lat, lon),
                )
                if cur.fetchone():
                    continue

                cur.execute(
                    f"""
                    INSERT INTO {COURTS_TABLE}(user_id, name, info, lat, lon)
                    VALUES (%s, %s, %s, %s, %s)
                    """,
                    (user_id, name, info, lat, lon),
                )
                inserted += 1
            except (TypeError, ValueError):
                continue

    return inserted


def ensure_courts_table(conn=None):
    """Garante uma tabela exclusiva e compatível para os pavilhões do mapa."""
    own_connection = conn is None
    connection = conn or get_db()

    try:
        if not _table_exists(connection, COURTS_TABLE):
            _create_courts_table(connection)
            # Tenta aproveitar uma tabela antiga chamada courts.
            _copy_rows_from_table(connection, "courts")
            return

        if _court_table_is_compatible(connection):
            return

        backup = _unique_backup_table_name(connection)
        with connection.cursor() as cur:
            cur.execute(f"RENAME TABLE `{COURTS_TABLE}` TO `{backup}`")
        _create_courts_table(connection)
        _copy_rows_from_table(connection, backup)
        _copy_rows_from_table(connection, "courts")
    finally:
        if own_connection:
            connection.close()


def load_default_courts():
    if not os.path.exists(COURTS_FILE):
        return []
    with open(COURTS_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data if isinstance(data, list) else []


def get_user_id():
    value = str(request.headers.get("X-User-Id", "")).strip()
    if not value.isdigit():
        return None
    return int(value)


def seed_courts_for_user(user_id):
    """Adiciona os pavilhões iniciais apenas quando o utilizador ainda não tem nenhum."""
    courts = load_default_courts()
    conn = get_db()
    try:
        ensure_courts_table(conn)
        with conn.cursor() as cur:
            cur.execute(f"SELECT COUNT(*) AS total FROM {COURTS_TABLE} WHERE user_id = %s", (user_id,))
            row = cur.fetchone() or {"total": 0}
            if int(row.get("total", 0)) > 0:
                return 0

            inserted = 0
            for item in courts:
                name = str(item.get("name") or "").strip()
                if len(name) < 2:
                    continue
                cur.execute(
                    f"""
                    INSERT INTO {COURTS_TABLE}(user_id, name, info, lat, lon)
                    VALUES (%s, %s, %s, %s, %s)
                    """,
                    (
                        user_id,
                        name,
                        str(item.get("info") or "").strip(),
                        float(item.get("lat")),
                        float(item.get("lon")),
                    ),
                )
                inserted += 1
            return inserted
    finally:
        conn.close()


def initialize_database():
    """Aplica a pequena migração e prepara pavilhões para contas já existentes."""
    conn = get_db()
    try:
        ensure_courts_table(conn)
        with conn.cursor() as cur:
            cur.execute("SELECT id FROM users")
            user_ids = [row["id"] for row in cur.fetchall()]
    finally:
        conn.close()

    for user_id in user_ids:
        seed_courts_for_user(user_id)


def initialize_database_with_retry(attempts=20, delay=2):
    last_error = None
    for _ in range(attempts):
        try:
            initialize_database()
            return
        except Exception as error:
            last_error = error
            time.sleep(delay)
    raise RuntimeError(f"Não foi possível preparar a base de dados: {last_error}")


@app.route("/health", methods=["GET"])
def health():
    try:
        conn = get_db()
        try:
            ensure_courts_table(conn)
            with conn.cursor() as cur:
                cur.execute(f"SELECT COUNT(*) AS total FROM {COURTS_TABLE}")
                total = int((cur.fetchone() or {}).get("total", 0))
        finally:
            conn.close()
        return jsonify({
            "ok": True,
            "courts_table": True,
            "courts_table_name": COURTS_TABLE,
            "courts_total": total,
        }), 200
    except Exception as error:
        traceback.print_exc()
        return jsonify({
            "ok": False,
            "error": "database_not_ready",
            "details": str(error),
            "type": error.__class__.__name__,
        }), 500


@app.route("/auth/register", methods=["POST"])
def register():
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""

    if len(username) < 3:
        return jsonify({"error": "Username muito curto."}), 400
    if len(password) < 6:
        return jsonify({"error": "Password muito curta."}), 400

    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT id FROM users WHERE username = %s", (username,))
            if cur.fetchone():
                return jsonify({"error": "Esse username já existe."}), 409

            cur.execute(
                "INSERT INTO users(username, password_hash) VALUES(%s, %s)",
                (username, generate_password_hash(password)),
            )
            user_id = cur.lastrowid

        seed_courts_for_user(user_id)
        return jsonify({"ok": True, "id": user_id}), 201
    finally:
        conn.close()


@app.route("/auth/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""

    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM users WHERE username = %s", (username,))
            user = cur.fetchone()

        if not user or not check_password_hash(user["password_hash"], password):
            return jsonify({"error": "Credenciais inválidas."}), 401

        return jsonify({
            "ok": True,
            "user": {
                "id": user["id"],
                "username": user["username"],
            },
        }), 200
    finally:
        conn.close()


@app.route("/contents", methods=["GET"])
def list_contents():
    user_id = get_user_id()
    if not user_id:
        return jsonify([]), 200

    q = (request.args.get("q") or "").strip()
    ids = (request.args.get("ids") or "").strip()

    conn = get_db()
    try:
        with conn.cursor() as cur:
            if ids:
                parts = [int(p) for p in ids.split(",") if p.isdigit()]
                if not parts:
                    return jsonify([]), 200
                placeholders = ",".join(["%s"] * len(parts))
                cur.execute(
                    f"SELECT * FROM contents WHERE user_id = %s AND id IN ({placeholders}) ORDER BY id DESC",
                    [user_id, *parts],
                )
            elif q:
                like = f"%{q}%"
                cur.execute(
                    """
                    SELECT * FROM contents
                    WHERE user_id = %s AND (name LIKE %s OR description LIKE %s)
                    ORDER BY id DESC
                    """,
                    (user_id, like, like),
                )
            else:
                cur.execute(
                    "SELECT * FROM contents WHERE user_id = %s ORDER BY id DESC",
                    (user_id,),
                )
            rows = cur.fetchall()
        return jsonify(rows), 200
    finally:
        conn.close()


@app.route("/contents/<int:cid>", methods=["GET"])
def get_content(cid):
    user_id = get_user_id()
    if not user_id:
        return jsonify({"error": "unauthorized"}), 401

    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT * FROM contents WHERE id = %s AND user_id = %s",
                (cid, user_id),
            )
            row = cur.fetchone()

        if not row:
            return jsonify({"error": "not_found"}), 404
        return jsonify(row), 200
    finally:
        conn.close()


@app.route("/contents", methods=["POST"])
def create_content():
    user_id = get_user_id()
    if not user_id:
        return jsonify({"error": "unauthorized"}), 401

    data = request.get_json(silent=True) or {}
    media_type = data.get("media_type")
    category = (data.get("category") or "").strip()
    name = (data.get("name") or "").strip()
    description = (data.get("description") or "").strip()
    media_filename = (data.get("media_filename") or "").strip()
    thumb_filename = data.get("thumb_filename")
    lat = data.get("lat")
    lon = data.get("lon")

    if media_type not in ("image", "video", "audio"):
        return jsonify({"error": "Tipo inválido."}), 400
    if category not in ("moment", "news"):
        return jsonify({"error": "Categoria inválida."}), 400
    if len(name) < 2:
        return jsonify({"error": "Nome inválido."}), 400
    if len(description) < 2:
        return jsonify({"error": "Descrição inválida."}), 400
    if not media_filename:
        return jsonify({"error": "Ficheiro/URL em falta."}), 400

    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO contents(user_id, media_type, category, name, description, lat, lon, media_filename, thumb_filename)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (user_id, media_type, category, name, description, lat, lon, media_filename, thumb_filename),
            )
            new_id = cur.lastrowid
        return jsonify({"ok": True, "id": new_id}), 201
    finally:
        conn.close()


@app.route("/contents/<int:cid>", methods=["PUT"])
def update_content(cid):
    user_id = get_user_id()
    if not user_id:
        return jsonify({"error": "unauthorized"}), 401

    data = request.get_json(silent=True) or {}
    name = (data.get("name") or "").strip()
    description = (data.get("description") or "").strip()
    category = (data.get("category") or "").strip()
    lat = data.get("lat")
    lon = data.get("lon")

    if len(name) < 2:
        return jsonify({"error": "Nome inválido."}), 400
    if len(description) < 2:
        return jsonify({"error": "Descrição inválida."}), 400
    if category not in ("moment", "news"):
        return jsonify({"error": "Categoria inválida."}), 400

    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT id FROM contents WHERE id = %s AND user_id = %s", (cid, user_id))
            if not cur.fetchone():
                return jsonify({"error": "not_found"}), 404

            cur.execute(
                """
                UPDATE contents
                SET name = %s, description = %s, category = %s, lat = %s, lon = %s
                WHERE id = %s AND user_id = %s
                """,
                (name, description, category, lat, lon, cid, user_id),
            )
        return jsonify({"ok": True}), 200
    finally:
        conn.close()


@app.route("/contents/<int:cid>", methods=["DELETE"])
def delete_content(cid):
    user_id = get_user_id()
    if not user_id:
        return jsonify({"error": "unauthorized"}), 401

    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM contents WHERE id = %s AND user_id = %s", (cid, user_id))
            if cur.rowcount == 0:
                return jsonify({"error": "not_found"}), 404
        return jsonify({"ok": True}), 200
    finally:
        conn.close()


@app.route("/courts", methods=["GET"])
def list_courts():
    user_id = get_user_id()
    if not user_id:
        return jsonify([]), 200

    # Também corrige automaticamente contas criadas antes de existir a tabela courts.
    seed_courts_for_user(user_id)

    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute(f"SELECT * FROM {COURTS_TABLE} WHERE user_id = %s ORDER BY id DESC", (user_id,))
            rows = cur.fetchall()
        return jsonify(rows), 200
    finally:
        conn.close()


@app.route("/courts", methods=["POST"])
def create_court():
    user_id = get_user_id()
    if not user_id:
        return jsonify({"error": "unauthorized"}), 401

    data = request.get_json(silent=True) or {}
    name = (data.get("name") or "").strip()
    info = (data.get("info") or "").strip()
    lat = data.get("lat")
    lon = data.get("lon")

    if len(name) < 2:
        return jsonify({"error": "name_invalid"}), 400

    try:
        lat = float(lat)
        lon = float(lon)
    except Exception:
        return jsonify({"error": "gps_invalid"}), 400

    if not (-90 <= lat <= 90) or not (-180 <= lon <= 180):
        return jsonify({"error": "gps_out_of_range"}), 400

    conn = get_db()
    try:
        ensure_courts_table(conn)
        with conn.cursor() as cur:
            cur.execute("SELECT id FROM users WHERE id = %s", (user_id,))
            if cur.fetchone() is None:
                return jsonify({
                    "error": "session_user_not_found",
                    "details": "A sessão refere um utilizador que já não existe. Termine sessão e volte a entrar."
                }), 401

            cur.execute(
                f"INSERT INTO {COURTS_TABLE}(user_id, name, info, lat, lon) VALUES (%s, %s, %s, %s, %s)",
                (user_id, name, info, lat, lon),
            )
            new_id = cur.lastrowid

            cur.execute(
                f"SELECT id, user_id, name, info, lat, lon, created_at FROM {COURTS_TABLE} WHERE id = %s",
                (new_id,),
            )
            created = cur.fetchone()

        return jsonify({"ok": True, "court": created}), 201
    finally:
        conn.close()


@app.route("/courts/<int:cid>", methods=["DELETE"])
def delete_court(cid):
    user_id = get_user_id()
    if not user_id:
        return jsonify({"error": "unauthorized"}), 401

    conn = get_db()
    try:
        ensure_courts_table(conn)
        with conn.cursor() as cur:
            cur.execute(f"DELETE FROM {COURTS_TABLE} WHERE id = %s AND user_id = %s", (cid, user_id))
            if cur.rowcount == 0:
                return jsonify({"error": "not_found"}), 404
        return jsonify({"ok": True}), 200
    finally:
        conn.close()


@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "not_found"}), 404


@app.errorhandler(Exception)
def server_error(error):
    traceback.print_exc()
    return jsonify({
        "error": "server_error",
        "details": str(error),
        "type": error.__class__.__name__,
    }), 500


if __name__ == "__main__":
    initialize_database_with_retry()
    app.run(host="0.0.0.0", port=5001)
