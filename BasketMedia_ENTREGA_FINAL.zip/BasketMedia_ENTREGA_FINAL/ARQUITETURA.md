# Arquitetura do trabalho

## Componentes

```text
Browser / JavaScript
        |
        | HTTP
        v
+-------------------------+
| web (Flask)             |
| apresentação e sessão   |
| cliente REST IoT        |
| subscriber MQTT         |
+-------------------------+
      |              |
      | HTTP/JSON    | Internet
      v              v
+-------------+   API Weather + Broker MQTT
| data-api    |
| regras/API  |
+-------------+
      |
      | SQL
      v
+-------------+
| MariaDB     |
+-------------+
```

A aplicação segue a separação entre apresentação, lógica de acesso e dados. As interações entre níveis são feitas através de interfaces HTTP/JSON bem definidas.

## Redes Docker

### `frontend`

- `web`
- `data-api`

Permite que o `web` consuma a API REST interna através de `http://data-api:5001`.

### `backend` interna

- `data-api`
- `db`

Está configurada com `internal: true`. O contentor `web` não pertence a esta rede e, portanto, não comunica diretamente com a MariaDB.

## Portas

Apenas a porta seguinte é publicada no computador:

```text
5000 -> web:5000
```

A `data-api` e a MariaDB são acessíveis apenas nas redes Docker.

## Comunicação IoT

- JavaScript/REST: `dashboard.js` faz pedidos periódicos à rota local do Flask; o `web` atua como proxy e faz os pedidos HTTPS à API Weather.
- MQTT: o contentor `web` carrega as credenciais de `config/mqtt.env`, autentica-se no broker e subscreve `/weather`.
- Browser: recebe ambos os resultados através de endpoints locais, evitando problemas de CORS e sem receber a password MQTT.

## Persistência

- dados de utilizadores, conteúdos e pavilhões: volume Docker `db_data`;
- uploads e thumbnails: diretórios montados no contentor `web`.
