# Conteúdo da entrega final

Esta pasta reúne num único projeto:

- Código completo da aplicação BasketMedia;
- Docker Compose e Dockerfiles;
- Serviço Web;
- API REST;
- Base de dados MariaDB;
- Dashboard IoT com REST e MQTT;
- Documentação Swagger/OpenAPI e Postman;
- Prompt da interface;
- Relatório consolidado das Fases 1, 2 e 3;
- Enunciados oficiais das três fases em `documentacao/enunciados/`.

O relatório principal encontra-se em `RELATORIO.md`.

- Relatório final formatado: `RELATORIO_BasketMedia_3_Fases.docx`;
- Critérios recebidos: `documentacao/criterios/Criterios_Avaliacao_Relatorio.png`.
