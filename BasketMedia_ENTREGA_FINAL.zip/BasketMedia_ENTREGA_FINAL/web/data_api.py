import os
import requests

DATA_API_URL = os.getenv("DATA_API_URL", "http://data-api:5001")


class DataApiResponse:
    def __init__(self, response):
        self.status_code = response.status_code
        self.ok = 200 <= response.status_code < 300
        self._response = response

    def json(self):
        if not self._response.content:
            return {}
        return self._response.json()


def api_request(method, path, *, json_data=None, params=None, headers=None, timeout=15):
    url = DATA_API_URL.rstrip("/") + path

    resp = requests.request(
        method=method,
        url=url,
        json=json_data,
        params=params,
        headers=headers or {},
        timeout=timeout,
    )

    return DataApiResponse(resp)
