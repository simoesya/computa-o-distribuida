from flask import Flask, render_template, request, redirect, url_for, session, jsonify, send_from_directory, abort
from werkzeug.utils import secure_filename
import atexit
import urllib.parse as urlparse
from data_api import api_request as rest_request
from iot_weather import fetch_weather_rest, mqtt_weather
import os

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "dev_secret_key_change_me")
app.config["MAX_CONTENT_LENGTH"] = int(os.getenv("MAX_CONTENT_LENGTH", str(200 * 1024 * 1024)))

BASE = os.path.dirname(os.path.abspath(__file__))
UPLOADS = os.path.join(BASE, "uploads")
THUMBS = os.path.join(BASE, "thumbs")
DOCS_DIR = os.path.join(BASE, "docs")

os.makedirs(UPLOADS, exist_ok=True)
os.makedirs(THUMBS, exist_ok=True)

ALLOWED_IMAGE = {"png", "jpg", "jpeg", "webp", "gif"}
ALLOWED_VIDEO = {"mp4", "webm", "ogg"}
ALLOWED_AUDIO = {"mp3", "wav", "ogg", "m4a"}


def ext_ok(filename, allowed):
    if not filename or "." not in filename:
        return False
    return filename.rsplit(".", 1)[1].lower() in allowed


def is_url_media(media_name):
    return bool(media_name) and media_name.startswith("url:")


def valid_remote_url(url):
    try:
        parsed = urlparse.urlparse((url or "").strip())
        return parsed.scheme in ("http", "https") and bool(parsed.netloc)
    except Exception:
        return False


def normalize_video_url(url):
    url = (url or "").strip()

    if "youtube.com/watch" in url:
        parsed = urlparse.urlparse(url)
        qs = urlparse.parse_qs(parsed.query)
        vid = qs.get("v", [None])[0]
        if vid:
            return f"https://www.youtube.com/embed/{vid}"

    if "youtu.be/" in url:
        vid = url.split("youtu.be/")[1].split("?")[0]
        if vid:
            return f"https://www.youtube.com/embed/{vid}"

    return url


def require_login():
    return "user_id" in session


def current_user_id():
    return session.get("user_id")


def login_required_view():
    if not require_login():
        return redirect(url_for("login"))
    return None


def api_request(method, path, *, json_data=None, params=None, timeout=15):
    headers = {}
    if require_login():
        headers["X-User-Id"] = str(current_user_id())

    return rest_request(
        method,
        path,
        json_data=json_data,
        params=params,
        headers=headers,
        timeout=timeout
    )


@app.route("/")
def home():
    if require_login():
        return redirect(url_for("contents"))
    return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    error = None
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""

        try:
            resp = api_request("POST", "/auth/register", json_data={
                "username": username,
                "password": password
            })
            if resp.status_code == 201:
                return redirect(url_for("login"))

            data = resp.json()
            error = data.get("error", "Erro no registo.")
        except Exception:
            error = "Não foi possível ligar ao serviço de dados."

    return render_template("register.html", error=error)


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""

        try:
            resp = api_request("POST", "/auth/login", json_data={
                "username": username,
                "password": password
            })
            if resp.status_code != 200:
                data = resp.json()
                error = data.get("error", "Credenciais inválidas.")
            else:
                data = resp.json()
                session["user_id"] = data["user"]["id"]
                session["username"] = data["user"]["username"]
                return redirect(url_for("contents"))
        except Exception:
            error = "Não foi possível ligar ao serviço de dados."

    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/contents")
def contents():
    r = login_required_view()
    if r:
        return r

    q = (request.args.get("q") or "").strip()
    try:
        resp = api_request("GET", "/contents", params={"q": q})
        rows = resp.json() if resp.ok else []
    except Exception:
        rows = []

    return render_template("contents.html", contents=rows, q=q)


@app.route("/contents/new", methods=["GET", "POST"])
def content_new():
    r = login_required_view()
    if r:
        return r

    error = None

    if request.method == "POST":
        media_type = request.form.get("media_type")
        category = (request.form.get("category") or "moment").strip()
        name = (request.form.get("name") or "").strip()
        description = (request.form.get("description") or "").strip()
        lat = (request.form.get("lat") or "").strip()
        lon = (request.form.get("lon") or "").strip()

        f = request.files.get("media_file")
        t = request.files.get("thumb_file")
        media_url = (request.form.get("media_url") or "").strip()

        has_file = (f and f.filename != "")
        has_url = (media_url != "")

        if media_type not in ("image", "video", "audio"):
            error = "Tipo inválido."
        elif category not in ("moment", "news"):
            error = "Categoria inválida."
        elif len(name) < 2:
            error = "Nome inválido."
        elif len(description) < 2:
            error = "Descrição inválida."
        elif not has_file and not has_url:
            error = "Escolha um ficheiro ou coloque um URL."
        elif has_file and has_url:
            error = "Use apenas UM: ficheiro OU URL."
        elif has_url and not valid_remote_url(media_url):
            error = "O URL deve começar por http:// ou https://."

        lat_val, lon_val = None, None
        if error is None and lat != "":
            try:
                lat_val = float(lat)
            except Exception:
                error = "Latitude inválida."
        if error is None and lon != "":
            try:
                lon_val = float(lon)
            except Exception:
                error = "Longitude inválida."

        if error is None and has_file:
            if media_type == "image" and not ext_ok(f.filename, ALLOWED_IMAGE):
                error = "Extensão de imagem inválida."
            elif media_type == "video" and not ext_ok(f.filename, ALLOWED_VIDEO):
                error = "Extensão de vídeo inválida."
            elif media_type == "audio" and not ext_ok(f.filename, ALLOWED_AUDIO):
                error = "Extensão de áudio inválida."

        if error is None and media_type == "video" and has_file:
            if not t or t.filename == "" or not ext_ok(t.filename, ALLOWED_IMAGE):
                error = "Vídeo precisa de thumbnail (imagem)."

        if error is None:
            saved_media_path = None
            saved_thumb_path = None

            if has_file:
                media_name = secure_filename(f.filename)
                base_name, ext = os.path.splitext(media_name)
                media_name = f"{base_name}_{current_user_id()}_{os.urandom(4).hex()}{ext}"
                saved_media_path = os.path.join(UPLOADS, media_name)
                f.save(saved_media_path)
            else:
                if media_type == "video":
                    media_url = normalize_video_url(media_url)
                media_name = "url:" + media_url

            thumb_name = None
            if media_type == "video" and has_file:
                thumb_name = secure_filename(t.filename)
                base_name, ext = os.path.splitext(thumb_name)
                thumb_name = f"{base_name}_{current_user_id()}_{os.urandom(4).hex()}{ext}"
                saved_thumb_path = os.path.join(THUMBS, thumb_name)
                t.save(saved_thumb_path)

            payload = {
                "media_type": media_type,
                "category": category,
                "name": name,
                "description": description,
                "lat": lat_val,
                "lon": lon_val,
                "media_filename": media_name,
                "thumb_filename": thumb_name
            }

            try:
                resp = api_request("POST", "/contents", json_data=payload)
                if resp.status_code == 201:
                    return redirect(url_for("contents"))
                error = resp.json().get("error", "Erro ao guardar conteúdo.")
            except Exception:
                error = "Não foi possível ligar ao serviço de dados."

            # Se a API falhar, não deixa ficheiros órfãos nas pastas locais.
            for path in (saved_media_path, saved_thumb_path):
                if path and os.path.exists(path):
                    try:
                        os.remove(path)
                    except OSError:
                        pass

    return render_template("content_form.html", mode="new", error=error, content=None)


@app.route("/contents/<int:cid>")
def content_detail(cid):
    r = login_required_view()
    if r:
        return r

    try:
        resp = api_request("GET", f"/contents/{cid}")
        if not resp.ok:
            abort(404)
        content = resp.json()
    except Exception:
        abort(404)

    return render_template("content_detail.html", content=content)


@app.route("/contents/<int:cid>/edit", methods=["GET", "POST"])
def content_edit(cid):
    r = login_required_view()
    if r:
        return r

    try:
        resp = api_request("GET", f"/contents/{cid}")
        if not resp.ok:
            abort(404)
        c = resp.json()
    except Exception:
        abort(404)

    error = None
    if request.method == "POST":
        name = (request.form.get("name") or "").strip()
        description = (request.form.get("description") or "").strip()
        category = (request.form.get("category") or "moment").strip()
        lat = (request.form.get("lat") or "").strip()
        lon = (request.form.get("lon") or "").strip()

        if len(name) < 2:
            error = "Nome inválido."
        elif len(description) < 2:
            error = "Descrição inválida."
        elif category not in ("moment", "news"):
            error = "Categoria inválida."

        lat_val, lon_val = None, None
        if error is None and lat != "":
            try:
                lat_val = float(lat)
            except Exception:
                error = "Latitude inválida."
        if error is None and lon != "":
            try:
                lon_val = float(lon)
            except Exception:
                error = "Longitude inválida."

        if error is None:
            payload = {
                "name": name,
                "description": description,
                "category": category,
                "lat": lat_val,
                "lon": lon_val
            }

            try:
                resp = api_request("PUT", f"/contents/{cid}", json_data=payload)
                if resp.ok:
                    return redirect(url_for("content_detail", cid=cid))
                error = resp.json().get("error", "Erro ao editar conteúdo.")
            except Exception:
                error = "Não foi possível ligar ao serviço de dados."

    return render_template("content_form.html", mode="edit", error=error, content=c)


@app.route("/contents/<int:cid>/delete", methods=["POST"])
def content_delete(cid):
    r = login_required_view()
    if r:
        return r

    try:
        resp = api_request("GET", f"/contents/{cid}")
        if not resp.ok:
            abort(404)
        c = resp.json()
    except Exception:
        abort(404)

    media_name = c["media_filename"]
    thumb_name = c["thumb_filename"]

    try:
        delete_response = api_request("DELETE", f"/contents/{cid}")
        if not delete_response.ok:
            abort(delete_response.status_code)
    except Exception:
        abort(503)

    # Só remove os ficheiros depois de a API confirmar a eliminação do registo.
    if media_name and not is_url_media(media_name):
        media_path = os.path.join(UPLOADS, media_name)
        if os.path.exists(media_path):
            try:
                os.remove(media_path)
            except OSError:
                pass

    if thumb_name:
        thumb_path = os.path.join(THUMBS, thumb_name)
        if os.path.exists(thumb_path):
            try:
                os.remove(thumb_path)
            except OSError:
                pass

    return redirect(url_for("contents"))


@app.route("/media/<path:filename>")
def media(filename):
    r = login_required_view()
    if r:
        return r

    if filename.startswith("url:"):
        abort(404)

    return send_from_directory(UPLOADS, filename, as_attachment=False, conditional=True)


@app.route("/thumbs/<path:filename>")
def thumbs(filename):
    r = login_required_view()
    if r:
        return r
    return send_from_directory(THUMBS, filename, as_attachment=False)


@app.route("/download/<int:cid>")
def download(cid):
    r = login_required_view()
    if r:
        return r

    try:
        resp = api_request("GET", f"/contents/{cid}")
        if not resp.ok:
            abort(404)
        c = resp.json()
    except Exception:
        abort(404)

    media_name = c["media_filename"]
    if is_url_media(media_name):
        abort(400)

    return send_from_directory(UPLOADS, media_name, as_attachment=True)


@app.route("/api/search")
def api_search():
    r = login_required_view()
    if r:
        return jsonify([])

    q = (request.args.get("q") or "").strip()
    try:
        resp = api_request("GET", "/contents", params={"q": q})
        rows = resp.json() if resp.ok else []
    except Exception:
        rows = []

    out = []
    for row in rows:
        media_name = row["media_filename"]
        media_url = media_name[4:] if is_url_media(media_name) else url_for("media", filename=media_name)
        out.append({
            "id": row["id"],
            "media_type": row["media_type"],
            "category": row["category"],
            "name": row["name"],
            "description": row["description"],
            "lat": row["lat"],
            "lon": row["lon"],
            "media_url": media_url,
            "is_remote": is_url_media(media_name),
            "download_url": None if is_url_media(media_name) else url_for("download", cid=row["id"]),
            "thumb_url": url_for("thumbs", filename=row["thumb_filename"]) if row["thumb_filename"] else None
        })

    return jsonify(out)


@app.route("/map")
def map_page():
    r = login_required_view()
    if r:
        return r
    ids = (request.args.get("ids") or "").strip()
    return render_template("map.html", ids=ids)


@app.route("/api/contents")
def api_contents():
    r = login_required_view()
    if r:
        return jsonify([])

    ids = (request.args.get("ids") or "").strip()
    params = {"ids": ids} if ids else {}

    try:
        resp = api_request("GET", "/contents", params=params)
        rows = resp.json() if resp.ok else []
    except Exception:
        rows = []

    out = []
    for row in rows:
        media_name = row["media_filename"]
        media_url = media_name[4:] if is_url_media(media_name) else url_for("media", filename=media_name)
        out.append({
            "id": row["id"],
            "media_type": row["media_type"],
            "category": row["category"],
            "name": row["name"],
            "description": row["description"],
            "lat": row["lat"],
            "lon": row["lon"],
            "media_url": media_url,
            "is_remote": is_url_media(media_name),
            "download_url": None if is_url_media(media_name) else url_for("download", cid=row["id"]),
            "thumb_url": url_for("thumbs", filename=row["thumb_filename"]) if row["thumb_filename"] else None
        })

    return jsonify(out)


@app.route("/dashboard")
def dashboard():
    r = login_required_view()
    if r:
        return r
    return render_template("dashboard.html")


@app.route("/api/iot/weather/rest")
def api_iot_weather_rest():
    r = login_required_view()
    if r:
        return jsonify({"ok": False, "error": "unauthorized"}), 401

    try:
        data = fetch_weather_rest()
        response = jsonify({"ok": True, **data})
        response.headers["Cache-Control"] = "no-store"
        return response, 200
    except Exception as error:
        return jsonify({
            "ok": False,
            "source": "REST",
            "error": "Não foi possível obter os dados do sensor por API REST.",
            "details": str(error),
        }), 503


@app.route("/api/iot/weather/mqtt")
def api_iot_weather_mqtt():
    r = login_required_view()
    if r:
        return jsonify({"ok": False, "error": "unauthorized"}), 401

    snapshot = mqtt_weather.snapshot()
    available = bool(snapshot.get("message"))
    has_error = bool(snapshot.get("last_error")) and not snapshot.get("connected")

    if available:
        state = "received"
        status_message = "Foi recebida uma publicação MQTT do sensor Weather."
    elif snapshot.get("connected"):
        state = "waiting"
        status_message = "Ligado ao broker e a aguardar uma publicação no tópico /weather."
    elif has_error:
        state = "error"
        status_message = snapshot.get("last_error")
    else:
        state = "connecting"
        status_message = "A estabelecer ligação ao broker MQTT."

    status = 503 if state == "error" else 200
    response = jsonify({
        "ok": state != "error",
        "available": available,
        "state": state,
        "status_message": status_message,
        "authentication": "configured" if snapshot.get("credentials_configured") else "not_configured",
        "source": "MQTT",
        **snapshot,
    })
    response.headers["Cache-Control"] = "no-store"
    return response, status


@app.route("/api/iot/health")
def api_iot_health():
    r = login_required_view()
    if r:
        return jsonify({"ok": False, "error": "unauthorized"}), 401

    snapshot = mqtt_weather.snapshot()
    return jsonify({
        "ok": True,
        "rest_proxy": True,
        "mqtt_enabled": snapshot.get("enabled"),
        "mqtt_connected": snapshot.get("connected"),
        "mqtt_topic": snapshot.get("topic"),
        "mqtt_credentials_configured": snapshot.get("credentials_configured"),
    })


@app.route("/api/courts", methods=["GET"])
def api_courts_list():
    r = login_required_view()
    if r:
        return jsonify([])

    try:
        resp = api_request("GET", "/courts")
        data = resp.json()
        if resp.ok:
            return jsonify(data), 200
        return jsonify({
            "error": "courts_service_error",
            "details": data,
        }), resp.status_code
    except Exception as error:
        return jsonify({
            "error": "service_unavailable",
            "details": str(error),
        }), 503


@app.route("/api/courts", methods=["POST"])
def api_courts_create():
    r = login_required_view()
    if r:
        return jsonify({"error": "unauthorized"}), 401

    data = request.get_json(silent=True) or {}
    try:
        resp = api_request("POST", "/courts", json_data=data)
        try:
            result = resp.json()
        except Exception:
            result = {"error": "invalid_api_response", "details": "A API de dados devolveu uma resposta inválida."}

        if resp.ok:
            return jsonify(result), resp.status_code

        return jsonify({
            "error": result.get("error", "courts_service_error"),
            "details": result.get("details") or result,
            "type": result.get("type"),
        }), resp.status_code
    except Exception as error:
        return jsonify({
            "error": "service_unavailable",
            "details": str(error),
            "type": error.__class__.__name__,
        }), 503


@app.route("/api/courts/<int:cid>", methods=["DELETE"])
def api_courts_delete(cid):
    r = login_required_view()
    if r:
        return jsonify({"error": "unauthorized"}), 401

    try:
        resp = api_request("DELETE", f"/courts/{cid}")
        return jsonify(resp.json()), resp.status_code
    except Exception:
        return jsonify({"error": "service_unavailable"}), 503


@app.route("/docs")
def api_docs():
    return render_template("swagger.html")


@app.route("/openapi.yaml")
def openapi_spec():
    return send_from_directory(DOCS_DIR, "openapi.yaml", mimetype="application/yaml")


@app.route("/docs/prompt-interface")
def prompt_interface_doc():
    return send_from_directory(
        DOCS_DIR,
        "PROMPT_INTERFACE.md",
        mimetype="text/markdown",
        as_attachment=False,
    )


@app.route("/docs/interface")
def interface_definition_doc():
    return send_from_directory(
        DOCS_DIR,
        "INTERFACE.md",
        mimetype="text/markdown",
        as_attachment=False,
    )


@app.route("/docs/postman")
def postman_collection_doc():
    return send_from_directory(
        DOCS_DIR,
        "BasketMedia.postman_collection.json",
        mimetype="application/json",
        as_attachment=True,
    )


@app.route("/docs/postman-environment")
def postman_environment_doc():
    return send_from_directory(
        DOCS_DIR,
        "BasketMedia.postman_environment.json",
        mimetype="application/json",
        as_attachment=True,
    )


if __name__ == "__main__":
    mqtt_weather.start()
    atexit.register(mqtt_weather.stop)
    app.run(host="0.0.0.0", port=5000, debug=False)
