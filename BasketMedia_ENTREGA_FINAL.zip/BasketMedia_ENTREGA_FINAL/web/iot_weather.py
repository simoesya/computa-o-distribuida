import json
import os
import ssl
import threading
from datetime import datetime, timezone
from urllib.parse import urljoin

import requests

try:
    import paho.mqtt.client as mqtt
except ImportError:  # permite abrir a aplicação mesmo sem a biblioteca instalada
    mqtt = None


WEATHER_API_BASE_URL = os.getenv(
    "WEATHER_API_BASE_URL",
    "https://cjsg.ddns.net:8443/weather/",
).rstrip("/") + "/"
WEATHER_API_TIMEOUT = float(os.getenv("WEATHER_API_TIMEOUT", "8"))
WEATHER_VERIFY_TLS = os.getenv("WEATHER_VERIFY_TLS", "true").lower() not in ("0", "false", "no")

MQTT_ENABLED = os.getenv("MQTT_ENABLED", "true").lower() not in ("0", "false", "no")
MQTT_HOST = os.getenv("MQTT_HOST", "cjsg.ddns.net")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
MQTT_TOPIC = os.getenv("MQTT_TOPIC", "/weather")
MQTT_USERNAME = os.getenv("MQTT_USERNAME", "")
MQTT_PASSWORD = os.getenv("MQTT_PASSWORD", "")
MQTT_TLS = os.getenv("MQTT_TLS", "false").lower() in ("1", "true", "yes")


def utc_now_iso():
    return datetime.now(timezone.utc).isoformat()


def _find_value(data, names):
    if not isinstance(data, dict):
        return None

    lower_names = {name.lower() for name in names}

    for key, value in data.items():
        if str(key).lower() in lower_names:
            return value

    for value in data.values():
        if isinstance(value, dict):
            found = _find_value(value, names)
            if found is not None:
                return found

    return None


def _number(value):
    if value is None or value == "":
        return None
    try:
        return float(str(value).replace(",", "."))
    except (TypeError, ValueError):
        return None


def normalize_weather(values, position=None):
    if isinstance(values, list) and values:
        values = values[0]
    if isinstance(position, list) and position:
        position = position[0]

    values = values if isinstance(values, dict) else {}
    position = position if isinstance(position, dict) else {}

    temperature = _number(_find_value(values, ("temperature", "temperatura", "temp")))
    humidity = _number(_find_value(values, ("humidity", "humidade", "humid")))
    reading_time = _find_value(values, ("time", "timestamp", "date", "datetime", "hora"))
    name = _find_value(values, ("name", "nome", "sensor", "device"))

    latitude = _number(_find_value(values, ("latitude", "lat")))
    longitude = _number(_find_value(values, ("longitude", "lon", "lng")))

    if latitude is None:
        latitude = _number(_find_value(position, ("latitude", "lat")))
    if longitude is None:
        longitude = _number(_find_value(position, ("longitude", "lon", "lng")))
    if not name:
        name = _find_value(position, ("name", "nome", "sensor", "device"))

    return {
        "name": name or "Sensor Weather",
        "temperature": temperature,
        "humidity": humidity,
        "time": reading_time,
        "latitude": latitude,
        "longitude": longitude,
    }


def fetch_weather_rest():
    headers = {"Accept": "application/json"}
    values_url = urljoin(WEATHER_API_BASE_URL, "values")
    position_url = urljoin(WEATHER_API_BASE_URL, "position")

    values_response = requests.get(
        values_url,
        headers=headers,
        timeout=WEATHER_API_TIMEOUT,
        verify=WEATHER_VERIFY_TLS,
    )
    values_response.raise_for_status()
    values = values_response.json()

    position = {}
    position_error = None
    try:
        position_response = requests.get(
            position_url,
            headers=headers,
            timeout=WEATHER_API_TIMEOUT,
            verify=WEATHER_VERIFY_TLS,
        )
        position_response.raise_for_status()
        position = position_response.json()
    except Exception as error:
        # A leitura principal continua válida mesmo que /position esteja indisponível.
        position_error = str(error)

    return {
        "source": "REST",
        "endpoint": values_url,
        "received_at": utc_now_iso(),
        "weather": normalize_weather(values, position),
        "raw": {
            "values": values,
            "position": position,
        },
        "position_warning": position_error,
    }


class MqttWeatherSubscriber:
    def __init__(self):
        self._lock = threading.Lock()
        self._client = None
        self._started = False
        self._connected = False
        self._last_message = None
        self._last_error = None
        self._received_at = None

    def start(self):
        if self._started or not MQTT_ENABLED:
            return

        self._started = True

        if mqtt is None:
            self._last_error = "A biblioteca paho-mqtt não está instalada."
            return

        try:
            try:
                client = mqtt.Client(
                    callback_api_version=mqtt.CallbackAPIVersion.VERSION1,
                    client_id=f"basketmedia-weather-{os.getpid()}",
                    clean_session=True,
                )
            except (AttributeError, TypeError):
                client = mqtt.Client(
                    client_id=f"basketmedia-weather-{os.getpid()}",
                    clean_session=True,
                )

            if MQTT_USERNAME:
                client.username_pw_set(MQTT_USERNAME, MQTT_PASSWORD)

            if MQTT_TLS:
                client.tls_set(cert_reqs=ssl.CERT_REQUIRED)

            client.on_connect = self._on_connect
            client.on_disconnect = self._on_disconnect
            client.on_message = self._on_message
            client.reconnect_delay_set(min_delay=2, max_delay=30)
            client.connect_async(MQTT_HOST, MQTT_PORT, keepalive=60)
            client.loop_start()
            self._client = client
        except Exception as error:
            with self._lock:
                self._last_error = str(error)

    def stop(self):
        client = self._client
        if not client:
            return
        try:
            client.loop_stop()
            client.disconnect()
        except Exception:
            pass

    def _on_connect(self, client, userdata, flags, rc):
        with self._lock:
            self._connected = (rc == 0)
            self._last_error = None if rc == 0 else f"Ligação MQTT recusada (código {rc})."

        if rc == 0:
            client.subscribe(MQTT_TOPIC, qos=0)

    def _on_disconnect(self, client, userdata, rc):
        with self._lock:
            self._connected = False
            if rc != 0:
                self._last_error = f"Ligação MQTT interrompida (código {rc})."

    def _on_message(self, client, userdata, message):
        try:
            text = message.payload.decode("utf-8")
            raw = json.loads(text)
            weather = normalize_weather(raw)

            with self._lock:
                self._last_message = {
                    "source": "MQTT",
                    "broker": f"{MQTT_HOST}:{MQTT_PORT}",
                    "topic": message.topic,
                    "qos": message.qos,
                    "received_at": utc_now_iso(),
                    "weather": weather,
                    "raw": raw,
                }
                self._received_at = self._last_message["received_at"]
                self._last_error = None
        except Exception as error:
            with self._lock:
                self._last_error = f"Mensagem MQTT inválida: {error}"

    def snapshot(self):
        with self._lock:
            return {
                "enabled": MQTT_ENABLED,
                "started": self._started,
                "connected": self._connected,
                "broker": f"{MQTT_HOST}:{MQTT_PORT}",
                "topic": MQTT_TOPIC,
                "credentials_configured": bool(MQTT_USERNAME and MQTT_PASSWORD),
                "received_at": self._received_at,
                "last_error": self._last_error,
                "message": self._last_message,
            }


mqtt_weather = MqttWeatherSubscriber()
