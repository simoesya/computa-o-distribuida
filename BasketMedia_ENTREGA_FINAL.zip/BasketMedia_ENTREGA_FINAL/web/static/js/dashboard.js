const REFRESH_SECONDS = 10;
let secondsLeft = REFRESH_SECONDS;
let refreshing = false;
let mapMarker = null;
let historyRows = [];

const map = L.map("iotMap").setView([38.7223, -9.1393], 8);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  maxZoom: 19,
  attribution: "&copy; OpenStreetMap"
}).addTo(map);

const sensorIcon = L.divIcon({
  html: '<div class="iotMapPin"><span>🌦️</span></div>',
  className: "iotMapPinWrap",
  iconSize: [42, 42],
  iconAnchor: [21, 42],
  popupAnchor: [0, -38]
});

function byId(id) {
  return document.getElementById(id);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function numberText(value, decimals = 1) {
  const number = Number(value);
  return Number.isFinite(number) ? number.toFixed(decimals) : "--";
}

function dateText(value) {
  if (!value) return "--";
  let input = value;
  if (typeof value === "number" && value < 1000000000000) {
    input = value * 1000;
  }
  const date = new Date(input);
  return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString("pt-PT");
}

async function getJson(url) {
  const response = await fetch(url, {
    headers: { "Accept": "application/json" },
    cache: "no-store"
  });

  let data = {};
  try {
    data = await response.json();
  } catch (error) {
    data = { ok: false, error: "Resposta inválida do servidor." };
  }

  return { response, data };
}

function setStatus(prefix, text, type) {
  const element = byId(`${prefix}Status`);
  element.textContent = text;
  element.className = `iotStatus ${type}`;
}

function clearCard(prefix) {
  byId(`${prefix}Temperature`).textContent = "--";
  byId(`${prefix}Humidity`).textContent = "--";
  byId(`${prefix}Name`).textContent = "--";
  byId(`${prefix}Time`).textContent = "--";
  byId(`${prefix}Received`).textContent = "--";
}

function renderWeather(prefix, weather, receivedAt) {
  byId(`${prefix}Temperature`).textContent = numberText(weather.temperature);
  byId(`${prefix}Humidity`).textContent = numberText(weather.humidity);
  byId(`${prefix}Name`).textContent = weather.name || "Sensor Weather";
  byId(`${prefix}Time`).textContent = dateText(weather.time);
  byId(`${prefix}Received`).textContent = dateText(receivedAt);
}

function addHistory(protocol, weather) {
  const row = {
    protocol,
    temperature: numberText(weather.temperature),
    humidity: numberText(weather.humidity),
    sensorTime: dateText(weather.time),
    localTime: new Date().toLocaleString("pt-PT")
  };

  const alreadyExists = historyRows.some(item =>
    item.protocol === row.protocol &&
    item.temperature === row.temperature &&
    item.humidity === row.humidity &&
    item.sensorTime === row.sensorTime
  );
  if (alreadyExists) return;

  historyRows.unshift(row);
  historyRows = historyRows.slice(0, 12);
  renderHistory();
}

function renderHistory() {
  const body = byId("iotHistory");
  if (historyRows.length === 0) {
    body.innerHTML = '<tr><td colspan="5">Ainda não foram recebidas leituras.</td></tr>';
    return;
  }

  body.innerHTML = historyRows.map(row => `
    <tr>
      <td><span class="iotProtocol ${row.protocol === "MQTT" ? "mqtt" : ""}">${escapeHtml(row.protocol)}</span></td>
      <td>${escapeHtml(row.temperature)} °C</td>
      <td>${escapeHtml(row.humidity)} %</td>
      <td>${escapeHtml(row.sensorTime)}</td>
      <td>${escapeHtml(row.localTime)}</td>
    </tr>
  `).join("");
}

function updateMap(weather, protocol) {
  const latitude = Number(weather.latitude);
  const longitude = Number(weather.longitude);

  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return;

  const popup = `
    <div class="iotPopup">
      <strong>${escapeHtml(weather.name || "Sensor Weather")}</strong>
      <p>Fonte mais recente: ${escapeHtml(protocol)}</p>
      <p>🌡️ ${escapeHtml(numberText(weather.temperature))} °C</p>
      <p>💧 ${escapeHtml(numberText(weather.humidity))} %</p>
      <small>${escapeHtml(dateText(weather.time))}</small>
    </div>
  `;

  if (!mapMarker) {
    mapMarker = L.marker([latitude, longitude], { icon: sensorIcon }).addTo(map);
  } else {
    mapMarker.setLatLng([latitude, longitude]);
  }

  mapMarker.bindPopup(popup);
  map.setView([latitude, longitude], 15);
  byId("mapStatus").textContent = `${latitude.toFixed(5)}, ${longitude.toFixed(5)}`;
}

async function loadRest() {
  setStatus("rest", "A atualizar…", "waiting");
  byId("restError").textContent = "";

  try {
    const { response, data } = await getJson("/api/iot/weather/rest");
    byId("restRaw").textContent = JSON.stringify(data, null, 2);

    if (!response.ok || !data.ok) {
      throw new Error(data.error || `HTTP ${response.status}`);
    }

    const weather = data.weather || {};
    renderWeather("rest", weather, data.received_at);
    byId("restEndpoint").textContent = data.endpoint || "--";
    setStatus("rest", "Online", "online");
    addHistory("REST", weather);
    updateMap(weather, "REST");
    return weather;
  } catch (error) {
    clearCard("rest");
    setStatus("rest", "Indisponível", "offline");
    byId("restError").textContent = error.message;
    return null;
  }
}

async function loadMqtt() {
  setStatus("mqtt", "A atualizar…", "waiting");
  byId("mqttError").textContent = "";

  try {
    const { response, data } = await getJson("/api/iot/weather/mqtt");
    byId("mqttRaw").textContent = JSON.stringify(data, null, 2);
    byId("mqttEndpoint").textContent = `${data.broker || "--"} · ${data.topic || "--"}`;
    byId("mqttAuth").textContent = data.credentials_configured
      ? "Credenciais configuradas"
      : "Sem credenciais";

    if (!response.ok || !data.ok) {
      throw new Error(data.status_message || data.last_error || `HTTP ${response.status}`);
    }

    if (!data.available || !data.message) {
      clearCard("mqtt");
      const statusText = data.state === "connecting" ? "A ligar…" : "A aguardar dados";
      setStatus("mqtt", statusText, "waiting");
      byId("mqttError").textContent = data.status_message ||
        "Ligado ao broker e a aguardar uma publicação no tópico /weather.";
      return null;
    }

    const weather = data.message.weather || {};
    renderWeather("mqtt", weather, data.message.received_at);
    setStatus("mqtt", data.connected ? "Ligado" : "Última leitura", data.connected ? "online" : "waiting");
    byId("mqttError").textContent = data.status_message || "Publicação MQTT recebida.";
    addHistory("MQTT", weather);
    updateMap(weather, "MQTT");
    return weather;
  } catch (error) {
    clearCard("mqtt");
    setStatus("mqtt", "Erro de ligação", "offline");
    byId("mqttAuth").textContent = "Não foi possível confirmar";
    byId("mqttError").textContent = error.message;
    return null;
  }
}

async function refreshDashboard() {
  if (refreshing) return;
  refreshing = true;
  byId("refreshDashboard").disabled = true;
  secondsLeft = REFRESH_SECONDS;

  await Promise.all([loadRest(), loadMqtt()]);

  refreshing = false;
  byId("refreshDashboard").disabled = false;
}

function updateCountdown() {
  if (!refreshing) {
    secondsLeft -= 1;
    if (secondsLeft <= 0) {
      secondsLeft = REFRESH_SECONDS;
      refreshDashboard();
    }
  }
  byId("nextRefresh").textContent = `Próxima atualização em ${secondsLeft} s`;
}

byId("refreshDashboard").addEventListener("click", refreshDashboard);
refreshDashboard();
setInterval(updateCountdown, 1000);
