(function () {
  const video = document.getElementById("vPlayer");
  const box = document.getElementById("vPreview");
  const img = document.getElementById("vPrevImg");
  const tEl = document.getElementById("vPrevTime");

  if (!video || !box || !img || !tEl) return;

  function fmtTime(sec) {
    sec = Math.max(0, Math.floor(sec || 0));
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return m + ":" + (s < 10 ? "0" : "") + s;
  }

  function show() { box.style.display = "block"; }
  function hide() { box.style.display = "none"; }

  function movePreview(ev) {
    const dur = video.duration;
    if (!dur || !isFinite(dur)) return;

    const r = video.getBoundingClientRect();
    const x = ev.clientX - r.left;
    const p = Math.max(0, Math.min(1, x / r.width));
    const sec = p * dur;

    tEl.textContent = fmtTime(sec);

    // posição horizontal da caixa da pop up
    const boxW = 220;
    let left = x - (boxW / 2);
    if (left < 10) left = 10;
    if (left > r.width - boxW - 10) left = r.width - boxW - 10;

    box.style.left = left + "px";
  }

  // Mostra preview quando o rato passa por cima do vídeo
  video.addEventListener("mousemove", (ev) => {
    show();
    movePreview(ev);
  });

  video.addEventListener("mouseenter", show);
  video.addEventListener("mouseleave", hide);
})();
