function onlyNumeric(ids) {
  return ids.filter(x => /^\d+$/.test(x));
}

function getAllVisibleIds() {
  const ids = Array.from(document.querySelectorAll("[data-id]"))
    .map(el => el.getAttribute("data-id"))
    .filter(Boolean);

  return onlyNumeric(ids);
}

function getSelectedIds() {
  const ids = Array.from(document.querySelectorAll("[data-id]"))
    .filter(el => el.querySelector(".sel") && el.querySelector(".sel").checked)
    .map(el => el.getAttribute("data-id"))
    .filter(Boolean);

  return onlyNumeric(ids);
}

document.getElementById("btnMapRes").addEventListener("click", () => {
  const ids = getAllVisibleIds();
  if (ids.length === 0) return alert("Não há resultados para mostrar no mapa.");
  window.location.href = `/map?ids=${ids.join(",")}`;
});

document.getElementById("btnMapSel").addEventListener("click", () => {
  const ids = getSelectedIds();
  if (ids.length === 0) return alert("Selecione pelo menos 1 conteúdo.");
  window.location.href = `/map?ids=${ids.join(",")}`;
});
