const mapEl = document.getElementById("map");
window.MAP_IDS = (mapEl && mapEl.dataset && mapEl.dataset.ids) ? mapEl.dataset.ids : "";

// MAPA BASE 
const map = L.map("map").setView([38.7223, -9.1393], 12);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  maxZoom: 19
}).addTo(map);

// ICONES 
const contentIcon = L.divIcon({
  html: `<div class="pin"><div class="pinInner">🏀</div></div>`,
  className: "basketPin",
  iconSize: [34, 34],
  iconAnchor: [17, 34],
  popupAnchor: [0, -30]
});

const courtIcon = L.divIcon({
  html: `<div class="pin"><div class="pinInner">🏟️</div></div>`,
  className: "basketPin",
  iconSize: [34, 34],
  iconAnchor: [17, 34],
  popupAnchor: [0, -30]
});

// CAMADAS 
const layerContents = L.layerGroup().addTo(map);
const layerCourts = L.layerGroup().addTo(map);

L.control.layers(null, {
  "Conteúdos": layerContents,
  "Campos/Pavilhões": layerCourts
}).addTo(map);

let allPoints = [];
let cachedContents = [];   // guarda conteúdos com GPS
const EPS = 0.00005;       // tolerância para comparar coordenadas

function sameCoord(a, b) {
  return Math.abs(a - b) <= EPS;
}

function escapeHtml(s) {
  return String(s ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function safeUrl(value) {
  const text = String(value || "").trim();
  if (text.startsWith("/") || text.startsWith("https://") || text.startsWith("http://")) {
    return escapeHtml(text);
  }
  return "";
}

function fitToAllPoints() {
  if (allPoints.length > 0) {
    map.fitBounds(L.latLngBounds(allPoints).pad(0.2));
  }
}

//  API HELPERS 
async function readJsonResponse(res) {
  let data = {};
  try {
    data = await res.json();
  } catch (_) {
    data = {};
  }
  if (!res.ok) {
    let detail = data.details || data.error || `HTTP ${res.status}`;

    if (data.error && data.details) {
      const detailsText = typeof data.details === "string"
        ? data.details
        : JSON.stringify(data.details);
      detail = `${data.error}: ${detailsText}`;
    }

    throw new Error(typeof detail === "string" ? detail : JSON.stringify(detail));
  }
  return data;
}

async function apiGetJson(url) {
  const res = await fetch(url, { cache: "no-store", credentials: "same-origin" });
  return await readJsonResponse(res);
}

async function apiCreateCourt(payload) {
  const res = await fetch("/api/courts", {
    method: "POST",
    credentials: "same-origin",
    headers: {
      "Content-Type": "application/json",
      "Accept": "application/json"
    },
    body: JSON.stringify(payload)
  });
  return await readJsonResponse(res);
}

async function apiDeleteCourt(id) {
  const res = await fetch(`/api/courts/${id}`, { method: "DELETE", credentials: "same-origin" });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return await res.json();
}

//CONTEUDOS 
async function loadContents() {
  layerContents.clearLayers();

  const qs = (window.MAP_IDS && window.MAP_IDS.length > 0)
    ? `?ids=${encodeURIComponent(window.MAP_IDS)}`
    : "";

  const data = await apiGetJson(`/api/contents${qs}`);

  data.forEach(c => {
    if (c.lat === null || c.lon === null) return;
    allPoints.push([c.lat, c.lon]);

    const cat = (c.category === "news") ? "Notícia" : "Momento";

    const mediaUrl = safeUrl(c.media_url);
    const thumbUrl = safeUrl(c.thumb_url);
    const downloadUrl = safeUrl(c.download_url);
    const downloadLink = downloadUrl
      ? `<a class="popupLink" href="${downloadUrl}">Download</a>`
      : "";

    let mediaHtml = "";
    if (c.media_type === "image") {
      const image = mediaUrl ? `<img src="${mediaUrl}" class="popupMedia" alt="">` : "";
      mediaHtml = `
        ${image}
        <div class="popupRow">
          <a class="popupBtn" href="/contents/${c.id}">Abrir</a>
          ${downloadLink}
        </div>
      `;
    } else if (c.media_type === "video") {
      const thumb = thumbUrl ? `<img src="${thumbUrl}" class="popupMedia" alt="thumbnail">` : "";
      mediaHtml = `
        ${thumb}
        <div class="popupRow">
          <a class="popupBtn" href="/contents/${c.id}">Ver</a>
          ${downloadLink}
        </div>
      `;
    } else {
      const audio = mediaUrl ? `<audio controls class="popupAudio"><source src="${mediaUrl}"></audio>` : "";
      mediaHtml = `
        ${audio}
        <div class="popupRow">
          <a class="popupBtn" href="/contents/${c.id}">Abrir</a>
          ${downloadLink}
        </div>
      `;
    }

    const html = `
      <div class="popupCard">
        <div class="popupTop">
          <span class="pill">${escapeHtml(cat)}</span>
          <strong>${escapeHtml(c.name)}</strong>
        </div>
        <p class="popupDesc">${escapeHtml(c.description)}</p>
        ${mediaHtml}
        <p class="popupGps">📍 ${c.lat}, ${c.lon}</p>
      </div>
    `;

    L.marker([c.lat, c.lon], { icon: contentIcon })
      .bindPopup(html, { maxWidth: 260 })
      .addTo(layerContents);
  });

  // guarda apenas conteúdos com GPS para cruzar com pavilhões
  cachedContents = data.filter(x => x.lat != null && x.lon != null);
}

//  Pavihoes Dinamicos 
let pendingDeleteId = null; // confirmação com 2 cliques

async function loadCourts() {
  layerCourts.clearLayers();

  let courts = [];
  try {
    courts = await apiGetJson("/api/courts");

    // garante conteúdos carregados cruzar as coordenadas
    if (!cachedContents || cachedContents.length === 0) {
      try {
        const tmp = await apiGetJson("/api/contents");
        cachedContents = (tmp || []).filter(x => x.lat != null && x.lon != null);
      } catch (e) {
        cachedContents = [];
      }
    }

  } catch (e) {
    console.log("Erro a carregar /api/courts:", e);
    setMsg(`Não foi possível carregar os pavilhões: ${e.message}`);
    return;
  }

  if (courts.length === 0) {
    setMsg("Ainda não existem pavilhões. Escreve um nome, ativa o modo de adicionar e clica no mapa.");
  } else if (!addMode) {
    setMsg("");
  }

  courts.forEach(c => {
    if (c.lat == null || c.lon == null) return;
    allPoints.push([c.lat, c.lon]);

    const isPending = (pendingDeleteId === c.id);

    // encontra conteúdos quetem as mesmas coordenadas
    const matches = cachedContents.filter(x =>
      x.lat != null && x.lon != null &&
      sameCoord(x.lat, c.lat) && sameCoord(x.lon, c.lon)
    );

    let matchesHtml = "";
    if (matches.length > 0) {
      matchesHtml = `
        <hr style="border:0;border-top:1px solid #ddd;margin:10px 0;">
        <div style="font-size:12px; margin-bottom:6px;"><strong>Conteúdos neste local</strong></div>
        ${matches.map(m => `
          <div style="display:flex; gap:8px; align-items:center; margin:6px 0;">
            ${m.media_type === "image" && safeUrl(m.media_url) ? `<img src="${safeUrl(m.media_url)}" style="width:56px;height:40px;object-fit:cover;border-radius:8px;">` : ""}
            ${m.media_type === "video" && safeUrl(m.thumb_url) ? `<img src="${safeUrl(m.thumb_url)}" style="width:56px;height:40px;object-fit:cover;border-radius:8px;">` : ""}
            ${m.media_type === "audio" ? `<span style="font-size:12px;">🎵 Áudio</span>` : ""}
            <a href="/contents/${m.id}" style="font-size:12px; text-decoration:underline;">
              ${escapeHtml(m.name)}
            </a>
          </div>
        `).join("")}
      `;
    }

    const html = `
      <div class="popupCard">
        <div class="popupTop">
          <span class="pill">Pavilhão</span>
          <strong>${escapeHtml(c.name)}</strong>
        </div>
        <p class="popupDesc">${escapeHtml(c.info || "")}</p>
        <p class="popupGps">📍 ${c.lat}, ${c.lon}</p>

        ${matchesHtml}

        <div class="popupRow">
          <a class="popupBtn" href="#" data-del-court="${c.id}">
            ${isPending ? "Confirmar apagar" : "Apagar"}
          </a>
        </div>
      </div>
    `;

    const marker = L.marker([c.lat, c.lon], { icon: courtIcon })
      .bindPopup(html, { maxWidth: 260 })
      .addTo(layerCourts);

    marker.on("popupopen", (e) => {
      const root = e.popup.getElement();
      const btn = root ? root.querySelector(`[data-del-court="${c.id}"]`) : null;
      if (!btn) return;

      btn.addEventListener("click", async (ev) => {
        ev.preventDefault();

        // 1º clique fazemos  confirmação
        if (pendingDeleteId !== c.id) {
          pendingDeleteId = c.id;
          await reloadAll(); // atualiza texto do botão
          return;
        }

        // 2º clique apagar
        try {
          await apiDeleteCourt(c.id);
          pendingDeleteId = null;
          await reloadAll();
        } catch (err) {
          pendingDeleteId = null;
          console.log(err);
        }
      });
    });
  });
}

// reload
async function reloadAll() {
  allPoints = [];
  await loadContents();
  await loadCourts();
  fitToAllPoints();
}

// modo adicionar
let addMode = false;

const btnAdd = document.getElementById("btnAddCourt");
const btnStop = document.getElementById("btnStopAdd");
const inName = document.getElementById("courtName");
const inInfo = document.getElementById("courtInfo");
const msg = document.getElementById("mapMsg");

function setMsg(t) {
  if (msg) msg.textContent = t || "";
}

function setAddMode(on) {
  addMode = on;
  if (btnAdd && btnStop) {
    btnAdd.style.display = on ? "none" : "inline-block";
    btnStop.style.display = on ? "inline-block" : "none";
  }
  setMsg(on ? "Clique no mapa para colocar o pavilhão." : "");
}

if (btnAdd && btnStop) {
  btnAdd.addEventListener("click", () => {
    pendingDeleteId = null;
    setAddMode(true);
  });

  btnStop.addEventListener("click", () => {
    setAddMode(false);
  });

  setAddMode(false);
}

map.on("click", async (e) => {
  if (!addMode) return;

  const name = (inName ? inName.value : "").trim();
  const info = (inInfo ? inInfo.value : "").trim();

  if (name.length < 2) {
    setMsg("Escreve um nome (mín. 2 caracteres) e depois clica no mapa.");
    return;
  }

  try {
    setMsg("A guardar o pavilhão...");
    if (btnStop) btnStop.disabled = true;

    const result = await apiCreateCourt({
      name: name,
      info: info,
      lat: Number(e.latlng.lat.toFixed(6)),
      lon: Number(e.latlng.lng.toFixed(6))
    });

    if (!result || !result.ok) {
      throw new Error("A API não confirmou a criação do pavilhão.");
    }

    if (inName) inName.value = "";
    if (inInfo) inInfo.value = "";
    setAddMode(false);
    await reloadAll();
    setMsg("Pavilhão adicionado com sucesso.");
    window.setTimeout(() => { if (!addMode) setMsg(""); }, 2500);
  } catch (err) {
    console.error("Erro ao criar pavilhão:", err);
    setMsg(`Erro ao criar pavilhão: ${err.message}`);
  } finally {
    if (btnStop) btnStop.disabled = false;
  }
});

// init
(async function init() {
  try {
    await reloadAll();
  } catch (err) {
    console.log(err);
    setMsg(`Erro ao carregar o mapa: ${err.message}`);
  }
})();
