# BasketMedia — Trabalho Prático Final (Fases 1, 2 e 3)

Este repositório corresponde à versão final acumulada das Fases 1, 2 e 3. O projeto utiliza contentores para separar a aplicação Web, a API REST de dados e a base de dados. Na Fase 3 foi acrescentado um dashboard IoT que utiliza o mesmo sensor Weather pelos dois acessos pedidos pelo professor:

- **JavaScript + API REST**: `dashboard.js` pede os dados a uma rota local Flask, que funciona como proxy para o sensor externo devido ao CORS;
- **MQTT**: o contentor `web` autentica-se no broker e subscreve o tópico `/weather`.

## Arquitetura

```text
Browser / JavaScript
        |
        | HTTP (mesma origem)
        v
Contentor web (Flask)
   |                 |
   | HTTP/JSON       | API REST externa + MQTT
   v                 v
Contentor data-api   Sensor Weather / Broker MQTT
        |
        | SQL
        v
Contentor db (MariaDB)
```

O browser apenas acede ao serviço `web` através da porta `5000`. A base de dados está numa rede Docker interna à qual o `web` não pertence.

## Fase 3 — Dashboard IoT

Depois do login, abrir:

```text
http://localhost:5000/dashboard
```

O dashboard inclui:

- painel de temperatura e humidade por API REST;
- painel da mesma informação recebida por MQTT;
- atualização automática de 10 em 10 segundos;
- atualização manual;
- mapa Leaflet com a posição do sensor;
- histórico das últimas leituras apresentadas;
- estado das ligações e mensagens de erro;
- visualização do JSON recebido.

### Solução para o CORS

O JavaScript não faz pedidos diretamente ao domínio externo do sensor. Em vez disso, utiliza rotas locais do Flask:

```text
GET /api/iot/weather/rest
GET /api/iot/weather/mqtt
```

O servidor Flask consome a API externa e mantém o subscriber MQTT. Como o browser comunica apenas com `localhost:5000`, os pedidos são da mesma origem e não ficam dependentes dos cabeçalhos CORS do servidor externo.

## Serviços Docker

1. **web** — interface Flask, templates, JavaScript, uploads, dashboard, cliente REST e subscriber MQTT.
2. **data-api** — API REST interna para login, conteúdos e pavilhões.
3. **db** — MariaDB para persistência.

## Executar

Na pasta do projeto:

```bash
docker compose up --build
```

Abrir:

```text
http://localhost:5000
```

Para acompanhar os dados MQTT e eventuais erros:

```bash
docker compose logs -f web
```

## Configuração do sensor

As credenciais MQTT fornecidas pelo professor estão configuradas em `config/mqtt.env` e são carregadas automaticamente pelo Docker Compose. Para alterar outras opções:

```bash
cp .env.example .env
```

Variáveis principais:

```text
WEATHER_API_BASE_URL=https://cjsg.ddns.net:8443/weather/
MQTT_HOST=cjsg.ddns.net
MQTT_PORT=1883
MQTT_TOPIC=/weather
MQTT_USERNAME=(configurado)
MQTT_PASSWORD=(configurada)
```

O dashboard nunca devolve a password ao browser. Apenas indica se as credenciais estão configuradas e se o subscriber está ligado ao broker.

## Parar

```bash
docker compose down
```

Apagar também os dados da MariaDB:

```bash
docker compose down -v
```

## Documentação

- `FASE3-IOT.md` — correspondência entre o enunciado e a implementação.
- `API.md` — endpoints REST internos.
- `ARQUITETURA.md` — separação dos componentes e redes Docker.


## Interface, prompt, Swagger e Postman

A interface encontra-se formalmente documentada e pode ser testada sem depender da conversa usada durante o desenvolvimento.

Depois de iniciar a aplicação:

```text
http://localhost:5000/docs
```

A página anterior abre o Swagger UI e inclui ligações para o prompt, definição da interface e coleção Postman. A especificação também pode ser obtida diretamente em:

```text
http://localhost:5000/openapi.yaml
```

Documentos associados:

- `PROMPT_INTERFACE.md` — prompt autónomo utilizado para definir a interface;
- `INTERFACE.md` — páginas, rotas, estados e forma de utilização;
- `openapi.yaml` — cópia do contrato OpenAPI 3 para entrega/importação;
- `web/docs/` — cópias servidas pela aplicação em execução;
- `postman/BasketMedia.postman_collection.json` — coleção Postman importável;
- `postman/BasketMedia.postman_environment.json` — ambiente local para Postman;
- `RELATORIO.md` — relatório completo das Fases 1, 2 e 3 em Markdown.

### Testar no Swagger

1. Criar uma conta e iniciar sessão na aplicação.
2. Abrir `/docs` na mesma janela/browser.
3. Expandir uma operação e selecionar **Try it out**.

### Testar no Postman

1. Importar os dois ficheiros da pasta `postman`.
2. Executar `Registo` apenas se ainda não existir conta.
3. Executar `Login`.
4. Executar os pedidos REST, MQTT, conteúdos e pavilhões.

O Postman mantém o cookie de sessão para os pedidos seguintes.

## Relatório final formatado

O relatório académico completo, formatado segundo os critérios de avaliação, encontra-se em:

```text
RELATORIO_BasketMedia_3_Fases.docx
```

O documento inclui capa, índices, numeração de páginas, capítulos iniciados em páginas ímpares, figuras, tabelas, listagens, acrónimos, modelo de dados, alternativas, testes, conclusões, trabalho futuro e bibliografia citada no texto.

## Correção automática dos pavilhões

A API cria automaticamente a tabela `courts` quando o projeto usa um volume MariaDB de uma versão anterior. As contas já existentes recebem os pavilhões iniciais na primeira consulta ao mapa. Não é necessário apagar o volume nem voltar a criar a conta.

Para adicionar um pavilhão: abra **Mapa**, escreva o nome, carregue em **Adicionar pavilhão** e clique no local pretendido.
