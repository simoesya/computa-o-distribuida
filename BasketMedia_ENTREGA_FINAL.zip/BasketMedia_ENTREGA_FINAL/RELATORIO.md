# BasketMedia — Relatório Passo a Passo das Fases 1, 2 e 3

## Identificação

- **Escola:** Escola Superior Náutica Infante D. Henrique
- **Curso:** Licenciatura em Engenharia Informática e Computadores
- **Unidade Curricular:** Computação Distribuída
- **Ano letivo:** 2025/2026
- **Docente:** Carlos Jorge Sousa Gonçalves
- **Projeto:** BasketMedia
- **Elementos do grupo:**
  - Dinis Lino — n.º 15041
  - Rodrigo Simões — n.º 15048
  - Guilherme Marques — n.º 15053
- **Data de entrega:** 15/06/2026

---

## Índice

1. Introdução  
2. Objetivos  
3. Tecnologias utilizadas  
4. Organização geral do projeto  
5. Fase 1 — Primeira adaptação para contentores  
6. Fase 2 — API REST e isolamento da base de dados  
7. Fase 3 — Dashboard IoT, REST, MQTT e CORS  
8. Funcionamento completo dos pedidos e respostas  
9. Documentação da API, Swagger e Postman  
10. Prompt da interface  
11. Como executar o projeto  
12. Testes realizados  
13. Problemas encontrados e soluções  
14. Conclusão  
15. Trabalho futuro  

---

# 1. Introdução

O BasketMedia é uma aplicação Web relacionada com basquetebol. A aplicação permite criar uma conta, iniciar sessão, adicionar conteúdos multimédia, pesquisar conteúdos, consultar pavilhões num mapa e visualizar dados de um sensor IoT.

O projeto original foi desenvolvido na Unidade Curricular de Programação Web. Na Unidade Curricular de Computação Distribuída, o projeto foi adaptado ao longo de três fases.

A evolução foi a seguinte:

```text
Fase 1:
Aplicação Web + componente de dados em contentores

Fase 2:
Browser → Web → API REST → MariaDB

Fase 3:
Dashboard IoT → API REST Weather + MQTT
```

A versão final junta os requisitos das três fases num único projeto.

---

# 2. Objetivos

Os principais objetivos foram:

- utilizar o modelo cliente/servidor;
- separar a apresentação, a lógica e os dados;
- comunicar entre processos através de uma rede;
- utilizar mensagens JSON;
- desenvolver e consumir uma API REST;
- executar os componentes em contentores;
- utilizar Docker Compose;
- impedir o acesso direto da aplicação Web à base de dados;
- integrar um sensor IoT através de REST;
- integrar o mesmo sensor através de MQTT;
- considerar as limitações de CORS;
- criar documentação da interface e da API;
- disponibilizar testes através de Swagger e Postman.

---

# 3. Tecnologias utilizadas

| Componente | Tecnologia |
|---|---|
| Aplicação Web | Python e Flask |
| Templates | HTML e Jinja |
| Estilos | CSS |
| Atualização do dashboard | JavaScript |
| Serviço de dados | Flask REST |
| Base de dados | MariaDB |
| Comunicação Web/API | HTTP e JSON |
| Acesso à base de dados | SQL e PyMySQL |
| Contentorização | Docker |
| Gestão dos contentores | Docker Compose |
| MQTT | Paho MQTT |
| Pedidos REST externos | Requests |
| Mapa | Leaflet e OpenStreetMap |
| Definição da API | OpenAPI 3 |
| Interface da API | Swagger UI |
| Testes manuais | Postman |

---

# 4. Organização geral do projeto

A pasta principal está organizada assim:

```text
BasketMedia_ENTREGA_FINAL/
│
├── docker-compose.yml
├── README.md
├── RELATORIO.md
├── API.md
├── ARQUITETURA.md
├── INTERFACE.md
├── FASE3-IOT.md
├── PROMPT_INTERFACE.md
├── openapi.yaml
│
├── web/
│   ├── server.py
│   ├── data_api.py
│   ├── iot_weather.py
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── templates/
│   ├── static/
│   ├── uploads/
│   └── thumbs/
│
├── data_service/
│   ├── api_server.py
│   ├── Dockerfile
│   ├── requirements.txt
│   └── courts.json
│
├── db/
│   └── init.sql
│
├── config/
│   └── mqtt.env
│
├── postman/
│   ├── BasketMedia.postman_collection.json
│   └── BasketMedia.postman_environment.json
│
└── documentacao/
    └── enunciados/
```

## 4.1. Serviço `web`

O serviço `web` é responsável por:

- mostrar as páginas HTML;
- receber os pedidos do browser;
- processar formulários;
- gerir sessões;
- comunicar com a API de dados;
- contactar a API REST Weather;
- receber mensagens MQTT;
- devolver dados JSON ao JavaScript.

## 4.2. Serviço `data_service`

O serviço `data_service` é responsável por:

- disponibilizar a API REST interna;
- validar os dados;
- criar utilizadores;
- autenticar utilizadores;
- criar, listar, alterar e eliminar conteúdos;
- gerir os pavilhões;
- executar as consultas SQL.

## 4.3. Serviço `db`

O serviço `db` utiliza MariaDB e guarda:

- utilizadores;
- conteúdos;
- pavilhões;
- referências para ficheiros multimédia.

---

# 5. Fase 1 — Primeira adaptação para contentores

## 5.1. Requisitos da Fase 1

Na primeira fase era necessário:

- separar a aplicação Web da componente de persistência;
- utilizar servidores distintos;
- comunicar através de JSON;
- executar os sistemas em contentores;
- utilizar uma solução Compose;
- expor no host apenas a aplicação Web.

## 5.2. Passo 1 — Analisar o projeto original

Primeiro foi analisada a aplicação de Programação Web para identificar:

- ficheiros Python;
- páginas HTML;
- ficheiros CSS e JavaScript;
- uploads;
- dados guardados;
- dependências Python;
- porta utilizada pela aplicação.

## 5.3. Passo 2 — Separar responsabilidades

A aplicação foi dividida logicamente em:

```text
Aplicação Web
    ↓
Componente de dados
```

A aplicação Web ficou responsável pela interface. A componente de dados ficou responsável pela persistência e devolução da informação.

## 5.4. Passo 3 — Criar os ficheiros `requirements.txt`

Foi criado um ficheiro `requirements.txt` para cada serviço Python.

Exemplo do serviço Web:

```text
Flask
requests
Werkzeug
paho-mqtt
```

O objetivo foi permitir que as dependências fossem instaladas automaticamente dentro da imagem Docker.

## 5.5. Passo 4 — Criar os Dockerfiles

Foi criado um `Dockerfile` para a aplicação Web e outro para o serviço de dados.

Estrutura utilizada:

```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .

RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["python", "server.py"]
```

Este processo:

1. escolhe uma imagem base;
2. cria o diretório de trabalho;
3. copia as dependências;
4. instala as bibliotecas;
5. copia o código;
6. inicia a aplicação.

## 5.6. Passo 5 — Criar o Docker Compose

Foi criado o ficheiro:

```text
docker-compose.yml
```

Este ficheiro permite:

- construir as imagens;
- iniciar os contentores;
- criar as redes;
- criar os volumes;
- definir variáveis de ambiente;
- publicar apenas a porta da aplicação Web.

## 5.7. Passo 6 — Publicar apenas o serviço Web

Apenas o serviço `web` possui uma porta publicada no host:

```yaml
ports:
  - "5000:5000"
```

Os restantes serviços ficam acessíveis apenas dentro das redes Docker.

## 5.8. Resultado da Fase 1

No final da primeira fase, o projeto já podia ser iniciado com:

```bash
docker compose up --build
```

A aplicação passou a ter uma execução reproduzível e isolada do computador do utilizador.

---

# 6. Fase 2 — API REST e isolamento da base de dados

## 6.1. Requisitos da Fase 2

Na segunda fase era necessário:

- utilizar três sistemas;
- ter uma aplicação Web;
- ter uma API REST intermédia;
- ter uma base de dados;
- impedir que o serviço Web acedesse diretamente à base de dados;
- permitir que apenas a API acedesse à MariaDB;
- utilizar Docker Compose.

A arquitetura implementada foi:

```text
Browser
   ↓ HTTP
web
   ↓ HTTP + JSON
data_service
   ↓ SQL
db
```

## 6.2. Passo 1 — Criar o serviço da API

Foi criado o ficheiro:

```text
data_service/api_server.py
```

Este ficheiro contém as rotas REST utilizadas pelo serviço Web.

Exemplos:

```text
POST /auth/register
POST /auth/login
GET /contents
POST /contents
PUT /contents/{id}
DELETE /contents/{id}
GET /courts
POST /courts
DELETE /courts/{id}
```

## 6.3. Passo 2 — Criar a base de dados

Foi criado:

```text
db/init.sql
```

O ficheiro cria as tabelas necessárias quando a MariaDB é iniciada pela primeira vez.

As principais tabelas são:

- `users`;
- `contents`;
- `courts`.

## 6.4. Passo 3 — Configurar a ligação da API à MariaDB

A API utiliza variáveis de ambiente para saber como contactar a base de dados:

```text
DB_HOST=db
DB_PORT=3306
DB_NAME=basketmedia
DB_USER=basketmedia
DB_PASSWORD=...
```

Dentro do Docker, o nome `db` corresponde ao nome do serviço definido no Compose.

## 6.5. Passo 4 — Remover o acesso direto do Web à base de dados

O serviço `web` não executa SQL.

Quando precisa de dados, envia um pedido HTTP para:

```text
http://data-service:5001
```

ou para o nome equivalente definido no `docker-compose.yml`.

## 6.6. Passo 5 — Criar o cliente interno da API

O ficheiro:

```text
web/data_api.py
```

centraliza os pedidos do Web para a API.

Exemplo conceptual:

```python
requests.get("http://data-service:5001/contents")
```

A resposta chega em JSON e é utilizada pelos templates Flask.

## 6.7. Passo 6 — Implementar o registo

O processo de registo funciona assim:

```text
1. Utilizador abre /register.
2. Preenche username e password.
3. Browser envia POST para o Web.
4. Web envia JSON à API.
5. API valida os dados.
6. API cria o hash da password.
7. API executa INSERT na MariaDB.
8. MariaDB confirma a operação.
9. API devolve JSON ao Web.
10. Web apresenta a mensagem ao utilizador.
```

Exemplo de JSON enviado:

```json
{
  "username": "aluno",
  "password": "password123"
}
```

## 6.8. Passo 7 — Implementar o login

O login funciona assim:

```text
1. Utilizador abre /login.
2. Introduz as credenciais.
3. Browser envia POST /login.
4. Web envia POST /auth/login à API.
5. API procura o utilizador na MariaDB.
6. MariaDB devolve o registo.
7. API verifica o hash da password.
8. API devolve o resultado em JSON.
9. Web cria a sessão.
10. Browser é redirecionado.
```

## 6.9. Passo 8 — Implementar o CRUD dos conteúdos

Foram implementadas as operações:

- criar;
- consultar;
- editar;
- eliminar.

### Criar conteúdo

```text
Browser → Web → API → INSERT → MariaDB
```

### Consultar conteúdos

```text
Browser → Web → API → SELECT → MariaDB
MariaDB → API → Web → Browser
```

### Editar conteúdo

```text
Browser → Web → API → UPDATE → MariaDB
```

### Eliminar conteúdo

```text
Browser → Web → API → DELETE → MariaDB
```

## 6.10. Passo 9 — Configurar as redes Docker

Foram utilizadas redes separadas.

Exemplo conceptual:

```text
frontend:
web ↔ data_service

backend:
data_service ↔ db
```

O serviço Web não pertence à rede interna da base de dados.

## 6.11. Passo 10 — Criar o volume da base de dados

Foi criado um volume Docker para manter os dados:

```yaml
volumes:
  db_data:
```

Assim, os registos não desaparecem quando os contentores são reiniciados.

## 6.12. Resultado da Fase 2

A arquitetura passou a cumprir o modelo:

```text
Apresentação → API REST → Persistência
```

A base de dados ficou protegida do acesso direto do serviço Web.

---

# 7. Fase 3 — Dashboard IoT, REST, MQTT e CORS

## 7.1. Requisitos da Fase 3

Na terceira fase era necessário:

- completar a interface com um dashboard IoT;
- obter dados através de uma API REST;
- obter dados através de MQTT;
- considerar as limitações de CORS;
- utilizar sensores ou atuadores disponíveis nos slides.

O sensor utilizado foi o sensor Weather, que fornece:

- temperatura;
- humidade;
- data/hora;
- nome;
- latitude;
- longitude.

O professor confirmou que bastava utilizar um sensor, desde que fosse acedido por JavaScript/REST e por MQTT.

## 7.2. Passo 1 — Identificar os acessos do sensor Weather

Foram utilizados os seguintes acessos.

### REST

```text
https://cjsg.ddns.net:8443/weather/values
https://cjsg.ddns.net:8443/weather/position
```

### MQTT

```text
Broker: cjsg.ddns.net
Porto: 1883
Tópico: /weather
Utilizador: cd
Password: configurada através de variável de ambiente
```

A password não é escrita no relatório.

## 7.3. Passo 2 — Criar o módulo IoT

Foi criado:

```text
web/iot_weather.py
```

Este módulo contém:

- configuração REST;
- configuração MQTT;
- pedido dos valores;
- pedido da posição;
- ligação ao broker;
- subscrição do tópico;
- receção das mensagens;
- armazenamento da última leitura MQTT.

## 7.4. Passo 3 — Implementar o acesso REST

O Web faz pedidos aos endpoints do professor através da biblioteca `requests`.

Fluxo:

```text
Browser
   ↓ GET /api/iot/weather/rest
Flask
   ↓ GET /weather/values
Servidor Weather
   ↑ JSON
Flask
   ↓ GET /weather/position
Servidor Weather
   ↑ JSON
Flask
   ↑ JSON normalizado
Browser
```

O Flask junta os valores e a posição numa única resposta.

Exemplo:

```json
{
  "ok": true,
  "source": "REST",
  "temperature": 23.4,
  "humidity": 61,
  "name": "Weather",
  "latitude": 38.7,
  "longitude": -9.1
}
```

## 7.5. Passo 4 — Tratar o CORS

O JavaScript não contacta diretamente o domínio externo.

Em vez disso, faz:

```text
GET /api/iot/weather/rest
```

O Flask funciona como intermediário:

```text
Browser → Flask local → API externa
```

Na resposta:

```text
API externa → Flask local → Browser
```

Desta forma, para o browser, o pedido é feito à mesma origem:

```text
http://localhost:5000
```

Isto evita o bloqueio de CORS.

## 7.6. Passo 5 — Configurar as credenciais MQTT

Foi criado:

```text
config/mqtt.env
```

Nesse ficheiro são definidas as variáveis:

```env
MQTT_HOST=cjsg.ddns.net
MQTT_PORT=1883
MQTT_TOPIC=/weather
MQTT_USERNAME=cd
MQTT_PASSWORD=<password fornecida pelo professor>
```

O `docker-compose.yml` carrega estas variáveis no serviço Web.

## 7.7. Passo 6 — Ligar ao broker MQTT

O Paho MQTT cria um cliente.

Passos:

```text
1. Criar o cliente MQTT.
2. Configurar username e password.
3. Definir a callback on_connect.
4. Definir a callback on_message.
5. Ligar a cjsg.ddns.net:1883.
6. Subscrever /weather.
7. Iniciar o ciclo de rede MQTT.
```

## 7.8. Passo 7 — Receber mensagens MQTT

Quando o broker envia uma mensagem:

```text
Sensor Weather
   ↓ publica
Broker MQTT
   ↓ distribui
Subscriber Web
```

A callback `on_message`:

1. recebe os bytes;
2. converte para texto;
3. interpreta o JSON;
4. guarda a última leitura;
5. guarda a hora local de receção.

Se ainda não tiver chegado nenhuma mensagem, o sistema devolve:

```json
{
  "ok": true,
  "state": "waiting",
  "available": false
}
```

O dashboard apresenta:

```text
A aguardar dados
```

## 7.9. Passo 8 — Criar as rotas IoT no Flask

Foram criadas rotas semelhantes a:

```text
GET /dashboard
GET /api/iot/weather/rest
GET /api/iot/weather/mqtt
GET /api/iot/health
```

A rota REST devolve os dados obtidos da API externa.

A rota MQTT devolve a última mensagem recebida pelo subscriber.

## 7.10. Passo 9 — Criar a página do dashboard

Foi criado:

```text
web/templates/dashboard.html
```

A página contém:

- cartão REST;
- cartão MQTT;
- temperatura;
- humidade;
- estado da ligação;
- nome do sensor;
- hora da leitura;
- endpoint;
- broker e tópico;
- botão para ver JSON;
- tabela das últimas leituras;
- mapa do sensor.

## 7.11. Passo 10 — Criar o JavaScript do dashboard

Foi criado:

```text
web/static/js/dashboard.js
```

O JavaScript:

1. pede os dados REST;
2. pede os dados MQTT;
3. atualiza os cartões;
4. atualiza a tabela;
5. atualiza o mapa;
6. apresenta erros;
7. repete os pedidos de 10 em 10 segundos.

Fluxo:

```text
JavaScript
   ↓
/api/iot/weather/rest
/api/iot/weather/mqtt
   ↓
Atualização da interface
```

## 7.12. Passo 11 — Mostrar o sensor no mapa

As coordenadas obtidas por:

```text
/weather/position
```

são utilizadas pelo Leaflet.

O mapa contém um marcador com um popup que apresenta:

- nome;
- temperatura;
- humidade;
- hora;
- protocolo utilizado.

## 7.13. Resultado da Fase 3

O dashboard ficou preparado para apresentar:

```text
REST:
Online ou Indisponível

MQTT:
Ligado, A aguardar dados ou Erro de ligação
```

O acesso REST e o acesso MQTT utilizam o sensor Weather, cumprindo os dois tipos de comunicação pedidos.

---

# 8. Funcionamento completo dos pedidos e respostas

## 8.1. Aplicação normal

### Ida

```text
Utilizador
   ↓
Browser
   ↓ HTTP
Web / Flask
   ↓ HTTP + JSON
API REST
   ↓ SQL
MariaDB
```

### Volta

```text
MariaDB
   ↓ resultado
API REST
   ↓ JSON
Web / Flask
   ↓ HTML ou JSON
Browser
   ↓
Utilizador
```

## 8.2. Weather por REST

### Pedido

```text
Browser → Flask → Servidor Weather
```

### Resposta

```text
Servidor Weather → Flask → Browser
```

## 8.3. Weather por MQTT

### Publicação

```text
Sensor → Broker → Subscriber Flask
```

### Consulta no dashboard

```text
Browser → Flask → última mensagem MQTT → Browser
```

---

# 9. Documentação da API, Swagger e Postman

## 9.1. API.md

O ficheiro:

```text
API.md
```

explica os endpoints, métodos HTTP, pedidos e respostas.

## 9.2. OpenAPI

O ficheiro:

```text
openapi.yaml
```

contém a definição formal da API.

## 9.3. Swagger

A interface Swagger está disponível em:

```text
http://localhost:5000/docs
```

Passos para testar:

```text
1. Abrir /docs.
2. Escolher um endpoint.
3. Carregar em Try it out.
4. Preencher os parâmetros.
5. Carregar em Execute.
6. Ver a resposta HTTP e o JSON.
```

## 9.4. Postman

Na pasta:

```text
postman/
```

existem:

```text
BasketMedia.postman_collection.json
BasketMedia.postman_environment.json
```

Passos:

```text
1. Abrir o Postman.
2. Escolher Import.
3. Importar os dois ficheiros.
4. Selecionar o ambiente BasketMedia.
5. Executar primeiro o registo ou o login.
6. Testar as rotas seguintes.
```

---

# 10. Prompt da interface

O prompt pedido pelo professor está guardado em:

```text
PROMPT_INTERFACE.md
```

O ficheiro descreve:

- páginas;
- navegação;
- formulários;
- CRUD;
- dashboard;
- REST;
- MQTT;
- mapa;
- CORS;
- Swagger;
- Postman;
- estados de erro.

O prompt foi escrito de forma autónoma para poder ser reutilizado sem depender da conversa original.

---

# 11. Como executar o projeto

## 11.1. Requisitos

É necessário ter:

- Docker Desktop;
- Docker Compose;
- browser.

## 11.2. Abrir a pasta

No terminal:

```bash
cd BasketMedia_ENTREGA_FINAL
```

## 11.3. Confirmar as variáveis MQTT

Verificar:

```text
config/mqtt.env
```

As credenciais devem estar configuradas.

## 11.4. Construir e iniciar

```bash
docker compose up --build
```

Ou em segundo plano:

```bash
docker compose up -d --build
```

## 11.5. Ver os contentores

```bash
docker compose ps
```

Devem aparecer:

```text
web
data-service
db
```

## 11.6. Abrir a aplicação

```text
http://localhost:5000
```

## 11.7. Criar uma conta

1. Abrir **Registo**.
2. Introduzir um username.
3. Introduzir uma password com pelo menos 6 caracteres.
4. Submeter.
5. Voltar ao login.

Exemplo:

```text
Username: aluno
Password: password123
```

## 11.8. Abrir o dashboard

Depois do login:

```text
http://localhost:5000/dashboard
```

## 11.9. Abrir o Swagger

```text
http://localhost:5000/docs
```

## 11.10. Parar o projeto

```bash
docker compose down
```

Para apagar também os volumes:

```bash
docker compose down -v
```

Este último comando elimina os dados guardados na MariaDB.

---

# 12. Testes realizados

## 12.1. Teste de arranque

```bash
docker compose up --build
```

Resultado esperado:

- contentor Web ativo;
- contentor da API ativo;
- MariaDB saudável.

## 12.2. Teste de registo

1. Criar conta.
2. Confirmar mensagem de sucesso.
3. Confirmar utilizador na base de dados.

## 12.3. Teste de login

1. Introduzir credenciais corretas.
2. Confirmar redirecionamento.
3. Introduzir credenciais incorretas.
4. Confirmar mensagem de erro.

## 12.4. Teste de conteúdos

- criar conteúdo;
- listar conteúdo;
- abrir detalhe;
- editar;
- eliminar.

## 12.5. Teste REST Weather

Abrir:

```text
/api/iot/weather/rest
```

Resultado esperado:

- `ok: true`;
- temperatura;
- humidade;
- posição.

## 12.6. Teste MQTT

Abrir:

```text
/api/iot/weather/mqtt
```

Resultados possíveis:

```text
received
waiting
connection_error
```

## 12.7. Teste do dashboard

Confirmar:

- atualização automática;
- dados REST;
- estado MQTT;
- histórico;
- mapa;
- JSON.

## 12.8. Teste do isolamento da base de dados

Confirmar que:

- apenas a API possui acesso ao serviço `db`;
- a porta 3306 não está publicada;
- o Web utiliza HTTP para obter os dados.

---

# 13. Problemas encontrados e soluções

## 13.1. Erro “Não foi possível ligar ao serviço de dados”

### Causa

O serviço Web não conseguia contactar a API.

### Solução

Iniciar todos os serviços através do Docker Compose:

```bash
docker compose down
docker compose up --build
```

## 13.2. REST Weather indisponível

### Possíveis causas

- DNS;
- certificado TLS;
- servidor do professor temporariamente indisponível;
- timeout.

### Solução

- confirmar o endpoint;
- testar dentro do contentor;
- configurar o timeout;
- configurar a validação TLS de acordo com o servidor de testes.

## 13.3. MQTT sem mensagens

### Causa

O broker podia estar ativo, mas o sensor não estava a publicar.

### Solução

Manter o subscriber ativo e mostrar:

```text
A aguardar dados
```

Sem criar valores falsos.

## 13.4. Autenticação MQTT

### Causa

O broker passou a exigir credenciais.

### Solução

Guardar as credenciais em:

```text
config/mqtt.env
```

e carregá-las através do Docker Compose.

## 13.5. CORS

### Causa

O browser podia bloquear pedidos diretos ao domínio externo.

### Solução

Utilizar o Flask como proxy:

```text
Browser → Flask → Weather API
```

---

# 14. Conclusão

O trabalho permitiu transformar uma aplicação Web numa aplicação distribuída composta por diferentes serviços.

Na Fase 1 foi iniciada a separação dos componentes e a utilização de contentores.

Na Fase 2 foi introduzida uma API REST entre a aplicação Web e a base de dados. A MariaDB passou a estar isolada e acessível apenas pela API.

Na Fase 3 foi criado um dashboard IoT com acesso ao sensor Weather por REST e MQTT. O Flask foi utilizado como intermediário para tratar o CORS e o JavaScript atualiza a interface de 10 em 10 segundos.

A versão final inclui:

- três contentores;
- comunicação HTTP e JSON;
- API REST;
- base de dados persistente;
- autenticação;
- CRUD de conteúdos;
- mapa;
- dashboard IoT;
- REST;
- MQTT;
- CORS;
- Swagger;
- Postman;
- documentação da interface;
- prompt da interface.

---

# 15. Trabalho futuro

Como melhorias futuras poderiam ser implementadas:

- paginação dos conteúdos;
- autenticação por tokens;
- proteção CSRF;
- maior validação dos uploads;
- armazenamento persistente do histórico IoT;
- utilização de InfluxDB;
- criação de gráficos através do Grafana;
- utilização de mais sensores;
- controlo de atuadores;
- testes automáticos;
- publicação da aplicação num servidor externo.
