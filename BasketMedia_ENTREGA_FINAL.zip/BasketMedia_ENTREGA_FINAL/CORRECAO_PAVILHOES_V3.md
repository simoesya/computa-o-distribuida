# Correção definitiva dos pavilhões

Esta versão usa uma tabela exclusiva chamada `basket_courts`, evitando conflitos com tabelas antigas chamadas `courts`.

## Aplicar

```bash
docker compose down
docker compose up -d --build --force-recreate
```

Não é necessário apagar o volume.

## Testar a API

```bash
docker compose exec web python -c "import requests; print(requests.get('http://data-api:5001/health').json())"
```

Resultado esperado:

```json
{
  "ok": true,
  "courts_table": true,
  "courts_table_name": "basket_courts"
}
```

Depois termine sessão e volte a entrar antes de testar o mapa.
