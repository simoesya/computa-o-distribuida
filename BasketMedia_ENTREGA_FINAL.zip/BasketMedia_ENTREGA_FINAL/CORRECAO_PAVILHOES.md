# Correção dos pavilhões

Esta versão corrige tabelas `courts` antigas ou incompatíveis.

## Aplicar a correção

Na pasta do projeto:

```bash
docker compose down
docker compose up -d --build --force-recreate
```

Não é necessário apagar o volume da base de dados.

## Confirmar a API

```bash
docker compose logs --tail=100 data-api
```

```bash
docker compose exec web python -c "import requests; print(requests.get('http://data-api:5001/health').text)"
```

Resultado esperado:

```json
{"ok":true,"courts_table":true}
```

A tabela anterior, quando incompatível, é mantida na base de dados com o nome
`courts_legacy` ou `courts_legacy_2`. Os registos compatíveis são migrados.
